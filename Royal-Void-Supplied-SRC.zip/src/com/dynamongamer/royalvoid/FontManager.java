package com.dynamongamer.royalvoid;

import android.content.Context;
import android.graphics.Typeface;
import java.util.HashMap;

public final class FontManager {
    private static final HashMap<String, Typeface> CACHE = new HashMap<String, Typeface>();
    
    private FontManager() {
    }
    
    public static synchronized Typeface get(Context c, String weight) {
        Typeface t = CACHE.get(weight);
        if (t != null) return t;
        try {
            t = Typeface.createFromAsset(c.getAssets(), "royal_void/fonts/ui_" + weight + ".ttf");
        } catch (Exception e) {
            t = Typeface.create("sans-serif", "bold".equals(weight) ? Typeface.BOLD : Typeface.NORMAL);
        }
        CACHE.put(weight, t);
        return t;
    }
}

/* Bundled Open Sans license:
Format: https://www.debian.org/doc/packaging-manuals/copyright-format/1.0/
Upstream-Name: Open Sans
Source: https://www.opensans.com/

Files: *
Copyright:
 Digitized data copyright (c) 2010-2011, Google Corporation.
License: Apache-2.0

Files: debian/*
Copyright:
 Copyright (c) 2017, Gregor Riepl <onitake@gmail.com>
License: Apache-2.0

License: Apache-2.0
 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at
 .
       http://www.apache.org/licenses/LICENSE-2.0
 .
 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 .
 On Debian systems, the complete text of the Apache License Version 2.0
 can be found in `/usr/share/common-licenses/Apache-2.0'.

*/
