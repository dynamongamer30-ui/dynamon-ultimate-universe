package top.niunaijun.blackbox.fake.service.context.providers;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public final class ProviderInvocationContract {
    private ProviderInvocationContract() {}
    public static void fixLegacyCaller(Class<?>[] parameters, Object[] args, String caller) {
        if (parameters.length > 0 && parameters[0] == String.class && args != null && args.length > 0) args[0] = caller;
    }
    public static Object invoke(Object provider, Method method, Object[] args) throws Throwable {
        try { return method.invoke(provider, args); }
        catch (InvocationTargetException failure) { throw failure.getCause(); }
    }
}
