package top.niunaijun.blackbox.fake.service;

/** Only OS-owned providers use the host path; imported app providers use guest resolution. */
public final class ProviderRoutePolicy {
    private ProviderRoutePolicy() {}
    public static boolean useHost(String authority) {
        return "settings".equals(authority) || "media".equals(authority) || "telephony".equals(authority)
            || "com.huawei.android.launcher.settings".equals(authority)
            || "com.hihonor.android.launcher.settings".equals(authority);
    }
}
