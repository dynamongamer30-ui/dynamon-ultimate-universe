package top.niunaijun.blackbox.utils.compat;

/** Decode either IAM or IActivityTaskManager arguments by their actual Intent position. */
public final class ActivityArguments {
    private ActivityArguments() {}
    public static Object afterIntent(Object[] args, Class<?> intentType, int offset) {
        if (args == null) return null;
        for (int i = 0; i < args.length; i++) {
            if (intentType.isInstance(args[i])) return i + offset < args.length ? args[i + offset] : null;
        }
        return null;
    }
}
