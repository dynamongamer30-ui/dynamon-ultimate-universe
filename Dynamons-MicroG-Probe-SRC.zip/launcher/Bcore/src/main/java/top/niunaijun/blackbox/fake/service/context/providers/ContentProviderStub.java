package top.niunaijun.blackbox.fake.service.context.providers;

import android.os.IInterface;
import java.lang.reflect.Method;
import black.android.content.BRAttributionSource;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.fake.hook.ClassInvocationStub;
import top.niunaijun.blackbox.utils.compat.ContextCompat;

/** Preserves provider data and exceptions; translates only the OS caller identity. */
public class ContentProviderStub extends ClassInvocationStub implements BContentProvider {
    private IInterface mBase;
    public IInterface wrapper(IInterface provider, String ignoredProviderOwner) {
        mBase = provider;
        injectHook();
        return (IInterface) getProxyInvocation();
    }
    @Override protected Object getWho() { return mBase; }
    @Override protected void inject(Object base, Object proxy) {}
    @Override protected void onBindMethod() {}
    @Override public boolean isBadEnv() { return false; }
    @Override public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        if (!"asBinder".equals(method.getName()) && args != null && args.length > 0) {
            // Never rewrite authority, selection, sort order, method, arg or Bundle data.
            ProviderInvocationContract.fixLegacyCaller(method.getParameterTypes(), args, BlackBoxCore.getHostPkg());
            Class<?> attribution = BRAttributionSource.getRealClass();
            if (args[0] != null && attribution != null && attribution.isInstance(args[0])) {
                // Android 12+ stores the UID/package in AttributionSourceState, not root fields.
                ContextCompat.fixAttributionSourceState(args[0], BlackBoxCore.getHostUid());
            }
        }
        return ProviderInvocationContract.invoke(mBase, method, args);
    }
}
