package top.niunaijun.blackbox.utils.compat;

import android.content.Context;
import android.content.ContextWrapper;
import android.util.*;

import black.android.app.BRContextImpl;
import black.android.app.BRContextImplKitkat;
import black.android.content.AttributionSourceStateContext;
import black.android.content.BRAttributionSource;
import black.android.content.BRAttributionSourceState;
import black.android.content.BRContentResolver;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.app.BActivityThread;
import top.niunaijun.blackbox.utils.Slog;


public class ContextCompat {
    public static final String TAG = "ContextCompat";

    public static void fixCallerAttribution(Object value) {
        if (value == null) return;
        try {
            Class<?> wrapped = BRAttributionSource.getRealClass();
            Object state = value;
            if (wrapped != null && wrapped.isInstance(value)) state = BRAttributionSource.get(value).mAttributionSourceState();
            if (state == null || !"android.content.AttributionSourceState".equals(state.getClass().getName())) return;
            fixOwnedState(state, 0);
        } catch (ReflectiveOperationException failure) {
            throw new IllegalStateException("Platform caller attribution unavailable", failure);
        }
    }

    private static void fixOwnedState(Object state, int depth) throws ReflectiveOperationException {
        if (state == null || depth >= 16) return;
        Class<?> type = state.getClass();
        java.lang.reflect.Field uid = type.getField("uid");
        java.lang.reflect.Field pkg = type.getField("packageName");
        String guest = BlackBoxCore.getAppPackageName();
        boolean owned = guest != null && guest.equals(pkg.get(state));
        if (owned && (uid.getInt(state) == BlackBoxCore.getBUid() || uid.getInt(state) == BlackBoxCore.getHostUid())) {
            uid.setInt(state, BlackBoxCore.getHostUid());
            pkg.set(state, BlackBoxCore.getHostPkg());
        }
        // Other apps in the chain keep their identity and platform permission decisions.
        Object next = type.getField("next").get(state);
        if (next != null && next.getClass().isArray()) for (int i = 0; i < java.lang.reflect.Array.getLength(next); i++)
            fixOwnedState(java.lang.reflect.Array.get(next, i), depth + 1);
    }

    public static void fixAttributionSourceState(Object obj, int uid) {
        Object mAttributionSourceState;
        if (obj != null && BRAttributionSource.get(obj)._check_mAttributionSourceState() != null) {
            mAttributionSourceState = BRAttributionSource.get(obj).mAttributionSourceState();

            AttributionSourceStateContext attributionSourceStateContext = BRAttributionSourceState.get(mAttributionSourceState);
            attributionSourceStateContext._set_packageName(BlackBoxCore.getHostPkg());
            attributionSourceStateContext._set_uid(uid);
            fixAttributionSourceState(BRAttributionSource.get(obj).getNext(), uid);
        }
    }

    public static void fix(Context context) {
        try {
            
            if (context == null) {
                Slog.w(TAG, "Context is null, skipping ContextCompat.fix");
                return;
            }
            
            int deep = 0;
            while (context instanceof ContextWrapper) {
                context = ((ContextWrapper) context).getBaseContext();
                deep++;
                if (deep >= 10) {
                    return;
                }
            }
            
            
            if (context == null) {
                Slog.w(TAG, "Base context is null after unwrapping, skipping ContextCompat.fix");
                return;
            }
            
            BRContextImpl.get(context)._set_mPackageManager(null);
            try {
                context.getPackageManager();
            } catch (Throwable e) {
                e.printStackTrace();
            }

            BRContextImpl.get(context)._set_mBasePackageName(BlackBoxCore.getHostPkg());
            BRContextImplKitkat.get(context)._set_mOpPackageName(BlackBoxCore.getHostPkg());
            
            try {
                BRContentResolver.get(context.getContentResolver())._set_mPackageName(BlackBoxCore.getHostPkg());
            } catch (Exception e) {
                Slog.w(TAG, "Failed to fix content resolver: " + e.getMessage());
            }

            if (BuildCompat.isS()) {
                try {
                    
                    
                    fixAttributionSourceState(BRContextImpl.get(context).getAttributionSource(), BlackBoxCore.getHostUid());
                } catch (Exception e) {
                    Slog.w(TAG, "Failed to fix attribution source state: " + e.getMessage());
                }
            }
        } catch (Exception e) {
            Slog.e(TAG, "Error in ContextCompat.fix: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
