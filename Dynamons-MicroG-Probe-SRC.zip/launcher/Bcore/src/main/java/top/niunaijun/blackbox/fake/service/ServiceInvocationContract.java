package top.niunaijun.blackbox.fake.service;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/** Forward a platform call exactly once; preserve its return type and original failure. */
public final class ServiceInvocationContract {
    private ServiceInvocationContract() {}
    public static Object invoke(Object service, Method method, Object[] args) throws Throwable {
        try { return method.invoke(service, args); }
        catch (InvocationTargetException failure) { throw failure.getCause(); }
    }
    public static void fixCaller(String method, Object[] args, String guest, int guestUid,
                                 String host, int hostUid) {
        if (args == null) return;
        // Identity package only: never replace arbitrary method, URL, attribution-tag or Bundle data.
        int pkg = -1;
        if (guest != null && !guest.equals(host)) {
            for (int i = 0; i < args.length; i++) if (args[i] instanceof String) {
                if (guest.equals(args[i])) pkg = i;
                break;
            }
        }
        if (pkg >= 0) {
            args[pkg] = host;
            // AppOps contracts place UID directly before the calling package.
            if (pkg > 0 && args[pkg - 1] instanceof Integer && guestUid > 0
                && ((Integer) args[pkg - 1]) == guestUid) args[pkg - 1] = hostUid;
        }
        // Connectivity explicitly accepts a caller UID for these legacy accessors.
        if (("getActiveNetworkForUid".equals(method) || "getActiveNetworkInfoForUid".equals(method))
            && args.length > 0 && args[0] instanceof Integer && guestUid > 0
            && ((Integer) args[0]) == guestUid) args[0] = hostUid;
    }
}
