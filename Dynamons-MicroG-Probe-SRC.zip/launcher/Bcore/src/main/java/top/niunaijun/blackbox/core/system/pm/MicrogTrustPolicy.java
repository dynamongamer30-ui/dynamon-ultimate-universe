package top.niunaijun.blackbox.core.system.pm;

/** Compatibility is restricted to the exact pinned replacement-service APKs. */
public final class MicrogTrustPolicy {
    public static final long BUNDLED_VERSION = 255070218L;
    public static final long BUNDLED_SIZE = 44666034L;
    public static final String BUNDLED_SHA256 = "5e7bed9c17b9fb27a23902b685ef44968019c31287fb1203ac6d41e0205d02bb";
    private MicrogTrustPolicy() {}
    public static boolean metadata(String pkg, long version, long size) {
        return "com.google.android.gms".equals(pkg)
            && (version == BUNDLED_VERSION && size == BUNDLED_SIZE
                || version == 252432034L && size == 108113833L)
            || "com.android.vending".equals(pkg) && version == 84022634L && size == 4210169L;
    }
    public static boolean trusted(String pkg, long version, long size, String sha256) {
        if (!metadata(pkg, version, size)) return false;
        return "com.google.android.gms".equals(pkg)
            && (version == BUNDLED_VERSION && BUNDLED_SHA256.equals(sha256)
                || version == 252432034L && "e5e6cba078bdec812b5450599350e5c1a12c8b7438da5bf77123af170f8c1a35".equals(sha256))
            || "com.android.vending".equals(pkg)
            && "9b8616011cc8f026bcbbe094df850794abb9d6d9f23214d7a8f8c4d1033ea012".equals(sha256);
    }
    public static boolean candidate(String pkg) {
        return "com.google.android.gms".equals(pkg) || "com.android.vending".equals(pkg);
    }
}
