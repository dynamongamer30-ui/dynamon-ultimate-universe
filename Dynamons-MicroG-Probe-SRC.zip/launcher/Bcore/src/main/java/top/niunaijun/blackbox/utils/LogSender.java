package top.niunaijun.blackbox.utils;
import java.io.File;
/** External upload is disabled in this host; reports are shared only by the user. */
public class LogSender {
 public static String send(String chatId, File logFile, String caption) { return "External log upload disabled"; }
}
