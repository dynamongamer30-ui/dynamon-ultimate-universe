import top.niunaijun.blackbox.fake.service.ServiceInvocationContract;
public final class ServiceInvocationContractTest {
    public static class Platform {
        int calls;
        final Object operation = new Object();
        final SecurityException denied = new SecurityException("not permitted");
        public Object noteOperation() { calls++; return operation; }
        public boolean connected() { calls++; return false; }
        public Object absent() { calls++; return null; }
        public void failure() { calls++; throw denied; }
    }
    static void require(boolean condition) { if (!condition) throw new AssertionError(); }
    public static void main(String[] args) throws Throwable {
        Platform p = new Platform();
        require(ServiceInvocationContract.invoke(p, Platform.class.getMethod("noteOperation"), null) == p.operation);
        require(Boolean.FALSE.equals(ServiceInvocationContract.invoke(p, Platform.class.getMethod("connected"), null)));
        require(ServiceInvocationContract.invoke(p, Platform.class.getMethod("absent"), null) == null);
        try { ServiceInvocationContract.invoke(p, Platform.class.getMethod("failure"), null); throw new AssertionError(); }
        catch (SecurityException failure) { require(failure == p.denied && p.calls == 4); }
        Object payload = new Object();
        Object[] call = {55, 10004, "guest.pkg", "attribution", payload};
        ServiceInvocationContract.fixCaller("noteOperation", call, "guest.pkg", 10004, "host.pkg", 10088);
        require(call[0].equals(55) && call[1].equals(10088) && call[2].equals("host.pkg") && call[3].equals("attribution") && call[4] == payload);
        Object[] host = {55, 10088, "host.pkg", "guest.pkg"};
        ServiceInvocationContract.fixCaller("noteOperation", host, "guest.pkg", 10004, "host.pkg", 10088);
        require(host[3].equals("guest.pkg"));
        Object[] network = {10004, true};
        ServiceInvocationContract.fixCaller("getActiveNetworkForUid", network, "guest.pkg", 10004, "host.pkg", 10088);
        require(network[0].equals(10088) && Boolean.TRUE.equals(network[1]));
        Object[] unrelated = {10004};
        ServiceInvocationContract.fixCaller("getNetwork", unrelated, "guest.pkg", 10004, "host.pkg", 10088);
        require(unrelated[0].equals(10004));
        System.out.println("8 real-return, single-call/error, caller and payload scenarios passed");
    }
}
