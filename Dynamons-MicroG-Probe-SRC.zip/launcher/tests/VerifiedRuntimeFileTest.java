package com.dynamongamer.containerprobe;
import java.io.*;
import java.nio.file.*;
public final class VerifiedRuntimeFileTest {
    private static final String SHA = "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad";
    private static void expect(boolean value) { if (!value) throw new AssertionError(); }
    private static void reject(byte[] bytes, long size, String sha, File target) throws Exception {
        try { VerifiedRuntimeFile.receive(new ByteArrayInputStream(bytes), target, size, sha, count -> {}); throw new AssertionError("accepted invalid payload"); }
        catch (IOException expected) {}
        expect(new String(Files.readAllBytes(target.toPath()), "UTF-8").equals("abc"));
        expect(!new File(target.getPath() + ".part").exists());
    }
    public static void main(String[] args) throws Exception {
        Path root = Files.createTempDirectory("microg-integrity-"); File target = root.resolve("runtime.apk").toFile();
        try {
            expect(!VerifiedRuntimeFile.matches(target, 3, SHA));
            VerifiedRuntimeFile.receive(new ByteArrayInputStream("abc".getBytes("UTF-8")), target, 3, SHA, count -> {});
            expect(VerifiedRuntimeFile.matches(target, 3, SHA));
            expect(!VerifiedRuntimeFile.matches(target, 4, SHA));
            reject("ab".getBytes("UTF-8"), 3, SHA, target);
            reject("abcd".getBytes("UTF-8"), 3, SHA, target);
            reject("abd".getBytes("UTF-8"), 3, SHA, target);
            InputStream failed = new InputStream() { public int read() throws IOException { throw new IOException("broken stream"); } };
            try { VerifiedRuntimeFile.receive(failed, target, 3, SHA, count -> {}); throw new AssertionError(); } catch (IOException expected) {}
            expect(VerifiedRuntimeFile.matches(target, 3, SHA)); expect(!new File(target.getPath() + ".part").exists());
            Thread.currentThread().interrupt();
            try { VerifiedRuntimeFile.receive(new ByteArrayInputStream(new byte[]{1}), target, 3, SHA, count -> {}); throw new AssertionError(); } catch (InterruptedIOException expected) {} finally { Thread.interrupted(); }
            expect(VerifiedRuntimeFile.matches(target, 3, SHA));
            System.out.println("8 runtime-integrity scenarios passed; failed downloads preserve the previous file");
        } finally { Files.deleteIfExists(target.toPath()); Files.deleteIfExists(root); }
    }
}
