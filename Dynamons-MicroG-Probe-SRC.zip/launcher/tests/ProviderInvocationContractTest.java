import java.lang.reflect.Method;
import top.niunaijun.blackbox.fake.service.context.providers.ProviderInvocationContract;
import top.niunaijun.blackbox.core.ProviderIdentityPolicy;
public final class ProviderInvocationContractTest {
    public static class Provider {
        public Object query(String caller, Object uri, String[] projection, String selection, String order) {
            if (!caller.equals("host.app") || !selection.equals("enabled=1") || !order.equals("name ASC")) throw new AssertionError("query changed");
            return projection;
        }
        public Object modern(Object attribution, String authority, String method, String arg, Object extras) { return extras; }
        public Object denied() { throw new SecurityException("provider denied"); }
        public Object nullable() { return null; }
    }
    public static void main(String[] unused) throws Throwable {
        Provider p = new Provider();
        String[] projection = {"exposure_scanner_enabled"}; Object uri = new Object();
        Object[] query = {"guest.app", uri, projection, "enabled=1", "name ASC"};
        Method legacy = Provider.class.getMethod("query", String.class, Object.class, String[].class, String.class, String.class);
        ProviderInvocationContract.fixLegacyCaller(legacy.getParameterTypes(), query, "host.app");
        if (ProviderInvocationContract.invoke(p, legacy, query) != projection || query[1] != uri) throw new AssertionError("payload references changed");
        Object identity = new Object(), bundle = new Object(); Object[] modern = {identity, "settings.authority", "get", "key", bundle};
        Method call = Provider.class.getMethod("modern", Object.class, String.class, String.class, String.class, Object.class);
        ProviderInvocationContract.fixLegacyCaller(call.getParameterTypes(), modern, "host.app");
        if (ProviderInvocationContract.invoke(p, call, modern) != bundle || modern[0] != identity || !modern[1].equals("settings.authority") || !modern[3].equals("key")) throw new AssertionError("modern payload changed");
        try { ProviderInvocationContract.invoke(p, Provider.class.getMethod("denied"), new Object[0]); throw new AssertionError("denial hidden"); } catch (SecurityException expected) {}
        if (ProviderInvocationContract.invoke(p, Provider.class.getMethod("nullable"), new Object[0]) != null) throw new AssertionError("null result fabricated");
        if (!ProviderIdentityPolicy.requiresPhysicalUid(new StackTraceElement[]{new StackTraceElement("android.content.ContentProvider$Transport", "query", "", 1)})) throw new AssertionError("provider boundary");
        if (ProviderIdentityPolicy.requiresPhysicalUid(new StackTraceElement[]{new StackTraceElement("org.microg.gms.settings.SettingsContract", "getSettings", "", 1)})) throw new AssertionError("guest identity altered");
        System.out.println("6 provider payload/error/identity scenarios passed");
    }
}
