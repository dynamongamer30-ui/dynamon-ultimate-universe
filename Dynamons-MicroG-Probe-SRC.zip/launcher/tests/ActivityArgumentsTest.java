import top.niunaijun.blackbox.utils.compat.ActivityArguments;
public final class ActivityArgumentsTest {
    static class Intent {}
    public static void main(String[] unused) {
        Intent intent=new Intent(); Object token=new Object(), options=new Object();
        Object[] old={new Object(),"caller",intent,"type",token,"who",12,34,null,options};
        Object[] modern={new Object(),"caller","feature",intent,"type",token,"who",12,34,null,options};
        for(Object[] args:new Object[][]{old,modern}) {
            if(ActivityArguments.afterIntent(args,Intent.class,0)!=intent || ActivityArguments.afterIntent(args,Intent.class,2)!=token || !ActivityArguments.afterIntent(args,Intent.class,4).equals(12) || ActivityArguments.afterIntent(args,Intent.class,7)!=options)throw new AssertionError("wrong launch decoding");
        }
        if(ActivityArguments.afterIntent(null,Intent.class,1)!=null || ActivityArguments.afterIntent(new Object[]{intent},Intent.class,7)!=null || ActivityArguments.afterIntent(new Object[]{"no intent"},Intent.class,0)!=null)throw new AssertionError("invalid arguments accepted");
        System.out.println("5 dual-layout and missing-argument scenarios passed");
    }
}
