import top.niunaijun.blackbox.app.ProviderInstallContract;
public final class ProviderInstallContractTest {
    static class Context {} static class ChildContext extends Context {} static class Provider {} static class Holder {}
    static class Thread {
        void installProvider(Context c, Holder h, Provider p, boolean a, boolean b, boolean d) {}
        void installProvider(String wrong) {}
    }
    static class ChildThread extends Thread {}
    public static void main(String[] args) throws Exception {
        if (ProviderInstallContract.find(Thread.class, ChildContext.class, Provider.class).getParameterCount() != 6) throw new AssertionError("wrong overload");
        if (ProviderInstallContract.find(ChildThread.class, Context.class, Provider.class).getDeclaringClass() != Thread.class) throw new AssertionError("inherited contract");
        try { ProviderInstallContract.find(Thread.class, Context.class, String.class); throw new AssertionError("wrong provider accepted"); } catch (NoSuchMethodException expected) {}
        System.out.println("3 provider installation contract checks passed");
    }
}
