import top.niunaijun.blackbox.app.LaunchPackageResolver;
public final class LaunchPackageResolverTest {
    public static void main(String[] args) {
        if (!"com.google.android.gms".equals(LaunchPackageResolver.resolve(null, "com.google.android.gms"))) throw new AssertionError("explicit microG activity must launch");
        if (!"com.funtomic.dynamons3".equals(LaunchPackageResolver.resolve("com.funtomic.dynamons3", "com.funtomic.dynamons3"))) throw new AssertionError("game intent regression");
        if (!"selected.app".equals(LaunchPackageResolver.resolve("selected.app", "component.app"))) throw new AssertionError("explicit package must be preserved");
        if (LaunchPackageResolver.resolve(null, null) != null) throw new AssertionError("missing target must remain missing");
        System.out.println("4 launch package regression cases passed");
    }
}
