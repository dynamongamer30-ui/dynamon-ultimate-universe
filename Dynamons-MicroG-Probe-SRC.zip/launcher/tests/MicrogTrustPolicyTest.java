import top.niunaijun.blackbox.core.system.pm.MicrogTrustPolicy;
public final class MicrogTrustPolicyTest {
    public static void main(String[] args) {
        String hash="e5e6cba078bdec812b5450599350e5c1a12c8b7438da5bf77123af170f8c1a35";
        if(!MicrogTrustPolicy.trusted("com.google.android.gms",252432034L,108113833L,hash))throw new AssertionError();
        if(MicrogTrustPolicy.trusted("com.funtomic.dynamons3",252432034L,108113833L,hash))throw new AssertionError("game certificate must remain real");
        if(MicrogTrustPolicy.trusted("com.google.android.gms",252432034L,108113833L,"corrupt"))throw new AssertionError();
        if(MicrogTrustPolicy.trusted("com.google.android.gms",252432035L,108113833L,hash))throw new AssertionError();
        if(MicrogTrustPolicy.trusted("com.google.android.gms",252432034L,108113832L,hash))throw new AssertionError();
        if(!MicrogTrustPolicy.trusted("com.android.vending",84022634L,4210169L,"9b8616011cc8f026bcbbe094df850794abb9d6d9f23214d7a8f8c4d1033ea012"))throw new AssertionError();
        if(!MicrogTrustPolicy.trusted("com.google.android.gms",MicrogTrustPolicy.BUNDLED_VERSION,MicrogTrustPolicy.BUNDLED_SIZE,MicrogTrustPolicy.BUNDLED_SHA256))throw new AssertionError("bundled runtime rejected");
        if(MicrogTrustPolicy.trusted("com.google.android.gms",MicrogTrustPolicy.BUNDLED_VERSION,MicrogTrustPolicy.BUNDLED_SIZE,"corrupt"))throw new AssertionError("corrupt bundled runtime trusted");
        if(MicrogTrustPolicy.trusted("com.google.android.gms",MicrogTrustPolicy.BUNDLED_VERSION+1,MicrogTrustPolicy.BUNDLED_SIZE,MicrogTrustPolicy.BUNDLED_SHA256))throw new AssertionError("wrong bundled version trusted");
        if(MicrogTrustPolicy.trusted("com.google.android.gms",MicrogTrustPolicy.BUNDLED_VERSION,MicrogTrustPolicy.BUNDLED_SIZE-1,MicrogTrustPolicy.BUNDLED_SHA256))throw new AssertionError("wrong bundled size trusted");
        if(MicrogTrustPolicy.metadata("com.funtomic.dynamons3",MicrogTrustPolicy.BUNDLED_VERSION,MicrogTrustPolicy.BUNDLED_SIZE))throw new AssertionError("game certificate override candidate");
        System.out.println("11 exact upstream/bundled service and wrong package/version/size/hash scenarios passed");
    }
}
