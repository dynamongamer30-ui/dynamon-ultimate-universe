import java.util.*;
import top.niunaijun.blackbox.core.system.accounts.InstalledAuthenticators;
public final class InstalledAuthenticatorsTest {
    public static void main(String[] args) {
        Map<String, String> services = new LinkedHashMap<>(); services.put("google", "gms"); services.put("other", "otherapp");
        if (InstalledAuthenticators.select(services, s -> true).size() != 2) throw new AssertionError("empty accounts must not hide services");
        if (!InstalledAuthenticators.select(services, s -> s.equals("gms")).equals(Arrays.asList("gms"))) throw new AssertionError("profile isolation");
        if (!InstalledAuthenticators.select(services, s -> false).isEmpty()) throw new AssertionError("uninstalled service exposed");
        if (!InstalledAuthenticators.select(Collections.<String,String>emptyMap(), s -> true).isEmpty()) throw new AssertionError("fake service invented");
        Map<String, String> refreshed = new LinkedHashMap<>(services); refreshed.remove("other");
        if (InstalledAuthenticators.select(refreshed, s -> true).size()!=1 || InstalledAuthenticators.select(services, s -> true).size()!=2) throw new AssertionError("snapshot independence");
        System.out.println("5 authenticator discovery scenarios passed");
    }
}
