from pathlib import Path
import subprocess,zipfile,re,json,sys,os
apk=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(exist_ok=True,parents=True)
selected={}
with zipfile.ZipFile(apk) as z:
 assert z.testzip() is None
 for entry in z.namelist():
  if not re.fullmatch(r'classes\d*\.dex',entry):continue
  f=out/entry;f.write_bytes(z.read(entry))
  proc=subprocess.Popen([os.environ.get('DEXDUMP','dexdump'),'-d',str(f)],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True,errors="replace")
  current=None;buf=[]
  for line in proc.stdout:
   if line.startswith('Class #'):
    if current:selected[current]=''.join(buf)
    current=None;buf=[]
   if 'Class descriptor' in line:
    descriptor=line.split("'")[1]
    if descriptor.startswith('Lorg/microg/gms/auth/login/LoginActivity') or descriptor in ['Lorg/microg/gms/auth/login/LoginPagePolicy;','Lorg/microg/gms/common/HttpFormClient;','Lorg/microg/gms/checkin/CheckinClient;','Lorg/microg/gms/people/PeopleManager;','Lorg/microg/gms/auth/AuthConstants;']:
     current=descriptor
   if current:buf.append(line)
  if current:selected[current]=''.join(buf)
  assert proc.wait()==0, 'DEX verification failed'
(out/'selected-methods.json').write_text(json.dumps(selected))
allcode='\n'.join(selected.values())
assert 'Lorg/microg/gms/auth/login/LoginActivity;' in selected
code=selected['Lorg/microg/gms/auth/login/LoginActivity;']
parts=re.split(r'      name          : ',code)
methods={}
for part in parts[1:]:methods[part.split("'")[1]]=part
start=methods['start']
assert 'loadLoginPage' in start and 'CheckinManager' not in start and '.checkin:' not in start, 'Initial page still waits on registration'
load=methods['loadLoginPage']
assert 'postDelayed' in load and 'WebView;.loadUrl' in load, 'Missing actual URL load and deadline'
assert 'EmbeddedSetup' in allcode and 'https://accounts.google.com' in allcode
assert 'onReceivedHttpError' in allcode and 'onReceivedError' in allcode and 'stopLoading' in allcode
assert 'isGoogleAccountPage' in allcode and 'setWebViewVisible' in allcode
for clazz in ['Lorg/microg/gms/common/HttpFormClient;','Lorg/microg/gms/checkin/CheckinClient;','Lorg/microg/gms/people/PeopleManager;']:
 c=selected[clazz];assert 'setConnectTimeout' in c and 'setReadTimeout' in c, 'Missing bounded transport'
assert 'post-login-registration' in allcode, 'Background post-login registration absent'
assert 'com.google' in selected['Lorg/microg/gms/auth/AuthConstants;'], 'Wrong standard account type'
print('Packaged DEX verified: real Google URL; page-before-checkin; bounded cookie/page/transport; error callback; background post-login work; standard account type.')
print('Inspected login-related classes:',len(selected))
