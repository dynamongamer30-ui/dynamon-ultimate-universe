import top.niunaijun.blackbox.core.system.am.ActivityStartContract;
public final class ActivityStartContractTest {
    public static class Intent {}
    public static class Modern {
        Object[] received;
        public int startActivity(Object caller, String pkg, String feature, Intent intent, String type, Object token, String who, int request, int flags, Object profiler, Object options) {
            received = new Object[]{caller,pkg,feature,intent,type,token,who,request,flags,profiler,options}; return -94;
        }
    }
    public static class Legacy {
        public int startActivity(Object caller, String pkg, Intent intent, String type, Object token, String who, int request, int flags, Object profiler, Object options) { return 3; }
    }
    public static class Denied extends Legacy {
        @Override public int startActivity(Object caller, String pkg, Intent intent, String type, Object token, String who, int request, int flags, Object profiler, Object options) { throw new SecurityException("denied"); }
    }
    public static void main(String[] ignored) throws Throwable {
        Modern manager = new Modern(); Object caller=new Object(),token=new Object(),options=new Object(); Intent intent=new Intent();
        int status=ActivityStartContract.invoke(manager,Intent.class,caller,"host.app",intent,"type",token,"who",12,34,options);
        if(status!=-94 || manager.received[2]!=null || manager.received[3]!=intent || manager.received[5]!=token || manager.received[10]!=options || !manager.received[7].equals(12)) throw new AssertionError("modern argument/result contract");
        if(ActivityStartContract.invoke(new Legacy(),Intent.class,caller,"host.app",intent,null,null,null,-1,0,null)!=3)throw new AssertionError("legacy result");
        try{ActivityStartContract.invoke(new Denied(),Intent.class,caller,"host.app",intent,null,null,null,-1,0,null);throw new AssertionError("failure swallowed");}catch(SecurityException expected){}
        try{ActivityStartContract.invoke(new Object(),Intent.class,caller,"host.app",intent,null,null,null,-1,0,null);throw new AssertionError("unsupported ABI accepted");}catch(NoSuchMethodException expected){}
        System.out.println("4 activity-launch ABI/status/error scenarios passed");
    }
}
