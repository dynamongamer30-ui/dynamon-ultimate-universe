import top.niunaijun.blackbox.core.system.accounts.AccountVisibilityPolicy;
public final class AccountVisibilityPolicyTest {
    static void require(boolean condition) { if (!condition) throw new AssertionError(); }
    public static void main(String[] args) {
        require(AccountVisibilityPolicy.resolve(3, true, 2) == 3);
        require(AccountVisibilityPolicy.resolve(1, false, 4) == 1);
        require(AccountVisibilityPolicy.resolve(null, true, null) == 1);
        require(AccountVisibilityPolicy.resolve(null, false, 2) == 2);
        require(AccountVisibilityPolicy.resolve(null, false, null) == 3);
        require(AccountVisibilityPolicy.resolve(null, false, 4) == 4);
        require(AccountVisibilityPolicy.readable(1) && AccountVisibilityPolicy.readable(2));
        require(!AccountVisibilityPolicy.readable(0) && !AccountVisibilityPolicy.readable(3) && !AccountVisibilityPolicy.readable(4));
        require(AccountVisibilityPolicy.matches(null, "com.google") && AccountVisibilityPolicy.matches("com.google", "com.google") && !AccountVisibilityPolicy.matches("other", "com.google"));
        System.out.println("9 owner, consent, explicit-denial, visibility and wildcard scenarios passed");
    }
}
