import top.niunaijun.blackbox.fake.service.ProviderRoutePolicy;
public final class ProviderRoutePolicyTest {
    public static void main(String[] args) {
        String[] guest = {"com.google.android.gsf.gservices", "com.google.android.gms.chimera",
            "com.google.android.gms.auth.accounts", "com.google.android.gms.phenotype",
            "com.android.vending.provider", "com.google.settings", "subscribedfeeds", "other.app", null};
        for (String authority : guest) if (ProviderRoutePolicy.useHost(authority)) throw new AssertionError("Wrong host route: " + authority);
        String[] host = {"settings", "media", "telephony", "com.huawei.android.launcher.settings", "com.hihonor.android.launcher.settings"};
        for (String authority : host) if (!ProviderRoutePolicy.useHost(authority)) throw new AssertionError("Wrong guest route: " + authority);
        System.out.println("14 provider-route checks passed");
    }
}
