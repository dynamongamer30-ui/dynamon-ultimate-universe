package com.dynamongamer.containerprobe;
import android.app.Application;
import android.content.Context;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.app.configuration.ClientConfiguration;
/** Source engine startup; original game files and account data are untouched. */
public final class ProbeApplication extends Application {
 static volatile String initialization="Not initialized";
 static volatile boolean ready;
 @Override protected void attachBaseContext(final Context base) {
  super.attachBaseContext(base);
  StartupDiagnostics.initialize(base);
  top.niunaijun.blackbox.core.system.accounts.AccountFlowObserver.setSink(new top.niunaijun.blackbox.core.system.accounts.AccountFlowObserver.Sink() {
   @Override public void event(top.niunaijun.blackbox.core.system.accounts.AccountFlowObserver.Stage stage) { StartupDiagnostics.event("Account flow: "+stage.name()); }
  });
  StartupDiagnostics.observeUncaughtFailures();
  try {
   StartupDiagnostics.event("Replacement BlackBox attach entered; page bytes="+CrashEvidence.pageSize());
   BlackBoxCore.get().addAppLifecycleCallback(new StartupDiagnostics());
   BlackBoxCore.get().doAttachBaseContext(base,new ClientConfiguration(){
    @Override public String getHostPackageName(){return base.getPackageName();}
    @Override public boolean isHideRoot(){return false;}
    @Override public boolean isUseVpnNetwork(){return false;}
    @Override public boolean isDisableFlagSecure(){return false;}
    @Override public String getLogSenderChatId(){return null;}
   });
   StartupDiagnostics.event("Replacement BlackBox attach returned");
   initialization="Replacement engine attach returned; game startup and Google login unverified";
   ready=true;
  }catch(Throwable failure){
   StartupDiagnostics.failure("Replacement engine attach failed",failure);
   initialization="Replacement engine attach failed: "+failure.getClass().getSimpleName();ready=false;
  }
 }
 @Override public void onCreate(){
  super.onCreate();
  if(!ready)return;
  try{
   StartupDiagnostics.event("Replacement BlackBox doCreate entered");
   BlackBoxCore.get().doCreate();
   StartupDiagnostics.event("Replacement BlackBox doCreate returned; client="+BlackBoxCore.get().isBlackProcess());
  }catch(Throwable failure){StartupDiagnostics.failure("Replacement engine create failed",failure);ready=false;}
 }
}
