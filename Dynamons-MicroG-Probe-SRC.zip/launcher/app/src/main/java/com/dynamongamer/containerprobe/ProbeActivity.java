package com.dynamongamer.containerprobe;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.entity.pm.InstallResult;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Experimental startup/Google dependency probe: no menu, save import or game patching. */
public final class ProbeActivity extends Activity {
    private static final String GAME = "com.funtomic.dynamons3";
    private static final int USER = 0;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final StringBuilder journal = new StringBuilder();
    private TextView log;
    private Button prepare;
    private Button launch;
    private Button google;
    private Button microgSettings;
    private Button microgLogin;
    private Button combinedSetup;
    private boolean busy;
    private volatile boolean compatible;
    private long nextLaunchAt;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int padding = Math.round(20 * getResources().getDisplayMetrics().density);
        panel.setPadding(padding, padding, padding, padding);
        scroll.addView(panel);
        TextView heading = new TextView(this);
        heading.setText("Dynamons microG Launcher\nPage-first login 0.5.0");
        heading.setTextSize(24);
        panel.addView(heading);
        TextView note = new TextView(this);
        note.setText("Uses a separate microG container. Android 16 microG compatibility and Google login are unverified. "
            + "Import the installed original game first. This has a separate game-data area; "
            + "your original save/account session is not copied. Prepare & sign in validates the game and microG together, then opens modified microG login. After the consent screen, Google’s page loads before device registration. Requests time out with an error if unavailable.");
        panel.addView(note);
        combinedSetup = addButton(panel, "Prepare & sign in");
        combinedSetup.setOnClickListener(view -> prepareAndSignIn());
        prepare = addButton(panel, "Import installed original game");
        google = addButton(panel, "Install bundled account services");
        google.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { setupGoogle(); }
        });
        microgSettings = addButton(panel, "Open microG settings & Self-Check");
        microgSettings.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { openMicroGSettings(); }
        });
        microgLogin = addButton(panel, "Open microG Google login");
        microgLogin.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { openMicroGLogin(); }
        });
        launch = addButton(panel, "Run full startup test");
        launch.setEnabled(false);
        prepare.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { importOriginal(); }
        });
        launch.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { launchInside(); }
        });
        addButton(panel, "Refresh startup diagnostics").setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { captureReport(false); }
        });
        addButton(panel, "Share startup report").setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { captureReport(true); }
        });
        log = new TextView(this);
        log.setTextIsSelectable(true);
        panel.addView(log);
        setContentView(scroll);
        String previous = getPreferences(MODE_PRIVATE).getString("startup_report", "");
        String reportVersion = getPreferences(MODE_PRIVATE).getString("report_version", "");
        if (reportVersion.equals("0.5.0") && !previous.isEmpty()) journal.append(previous).append("\n--- New host session ---\n");
        else if (!previous.isEmpty()) getPreferences(MODE_PRIVATE).edit().putString("previous_build_report", previous).apply();
        getPreferences(MODE_PRIVATE).edit().putString("report_version", "0.5.0").apply();
        record("Host probe version: 0.5.0; original game version is reported separately.");
        record("Android API " + Build.VERSION.SDK_INT + "; ABI " + Arrays.toString(Build.SUPPORTED_ABIS));
        record(ProbeApplication.initialization);
        prepare.setEnabled(ProbeApplication.ready);
        combinedSetup.setEnabled(ProbeApplication.ready);
        google.setEnabled(ProbeApplication.ready && !busy); microgSettings.setEnabled(ProbeApplication.ready && !busy); microgLogin.setEnabled(ProbeApplication.ready && !busy);
        if (Build.VERSION.SDK_INT >= 36) record("Android 16: compatibility test, not verified SDK support.");
    }

    private Button addButton(LinearLayout panel, String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        panel.addView(button);
        return button;
    }

    private void record(final String message) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                if (isDestroyed()) return;
                journal.append(message).append('\n');
                if (journal.length() > 32768) journal.delete(0, journal.length() - 32768);
                getPreferences(MODE_PRIVATE).edit().putString("startup_report", journal.toString()).apply();
                renderReport();
            }
        });
    }

    private void prepareAndSignIn() {
        if (busy || !ProbeApplication.ready) return;
        busy = true;
        compatible = false;
        combinedSetup.setEnabled(false);
        prepare.setEnabled(false); google.setEnabled(false); microgSettings.setEnabled(false);
        microgLogin.setEnabled(false); launch.setEnabled(false);
        record("Preparing the original game and bundled account services together; existing game/account data retained.");
        worker.execute(() -> {
            boolean prepared = false;
            try {
                PackageInfo original = getPackageManager().getPackageInfo(GAME, 0);
                PackageInfo guest = BlackBoxCore.getBPackageManager().getPackageInfo(GAME, 0, USER);
                String blocked = validateOriginal(original, guest);
                if (blocked != null) {
                    InstallResult result = BlackBoxCore.get().installPackageAsUser(GAME, USER);
                    if (result == null || !result.success) throw new IllegalStateException("Original import failed");
                    guest = BlackBoxCore.getBPackageManager().getPackageInfo(GAME, 0, USER);
                    blocked = validateOriginal(original, guest);
                }
                if (blocked != null) { record("Preparation stopped: " + blocked); return; }
                compatible = true;
                record("Original game base and splits validated. This does not establish Google login.");
                MicroGRuntime.setup(ProbeActivity.this, USER, message -> record(message));
                prepared = MicroGRuntime.ready(ProbeActivity.this, USER);
                if (!prepared) record("Preparation stopped: runtime validation failed.");
            } catch (Throwable failure) {
                StartupDiagnostics.failure("Combined preparation failed", failure);
                record("Preparation failed: " + failure.getClass().getSimpleName());
            } finally {
                final boolean open = prepared;
                runOnUiThread(() -> {
                    if (isDestroyed()) return;
                    busy = false;
                    combinedSetup.setEnabled(ProbeApplication.ready);
                    prepare.setEnabled(ProbeApplication.ready); google.setEnabled(ProbeApplication.ready);
                    microgSettings.setEnabled(ProbeApplication.ready); microgLogin.setEnabled(ProbeApplication.ready);
                    launch.setEnabled(compatible && android.os.SystemClock.elapsedRealtime() >= nextLaunchAt);
                    if (open) openMicroGLogin();
                });
            }
        });
    }

    private String validateOriginal(PackageInfo original, PackageInfo guest) throws Exception {
        if (guest == null || guest.applicationInfo == null || original.applicationInfo == null) return "Missing original/container metadata";
        if (guest.versionCode != original.versionCode) return "Game version mismatch";
        return SplitImportCheck.check(original.splitNames, guest.splitNames, guest.applicationInfo.splitNames,
            original.applicationInfo.sourceDir, guest.applicationInfo.sourceDir,
            original.applicationInfo.splitSourceDirs, guest.applicationInfo.splitSourceDirs);
    }

    private void importOriginal() {
        if (busy) return;
        busy = true;
        google.setEnabled(false); microgSettings.setEnabled(false); microgLogin.setEnabled(false);
        compatible = false;
        launch.setEnabled(false);
        prepare.setEnabled(false);
        record("Import requested. Original installed APK files are not rebuilt or re-signed.");
        worker.execute(new Runnable() {
            @Override public void run() {
                try {
                    PackageInfo original = getPackageManager().getPackageInfo(GAME, 0);
                    record("Original version: " + original.versionName + "; splits: " + Arrays.toString(original.splitNames));
                    PackageInfo guest = BlackBoxCore.getBPackageManager().getPackageInfo(GAME, 0, USER);
                    // Startup readiness may lag the engine's installed boolean. Use actual metadata,
                    // retry briefly, then re-import in place; Settings preserves existing user state.
                    for (int retry = 0; guest == null && retry < 3; retry++) {
                        Thread.sleep(150);
                        guest = BlackBoxCore.getBPackageManager().getPackageInfo(GAME, 0, USER);
                    }
                    if (guest == null) {
                        record("Valid package metadata unavailable; importing installed original in place, without clearing game data.");
                        InstallResult result = BlackBoxCore.get().installPackageAsUser(GAME, USER);
                        if (result == null || !result.success) {
                            record("Import failed: " + (result == null ? "no engine result" : result.msg)); return;
                        }
                        guest = BlackBoxCore.getBPackageManager().getPackageInfo(GAME, 0, USER);
                    } else record("Existing replacement-engine metadata available; validating it.");
                    if (guest == null) { record("Imported package information is unavailable after import."); return; }
                    if (guest.versionCode != original.versionCode) {
                        record("Launch blocked: original and container game versions differ.");
                        return;
                    }
                    record("Container PackageInfo split names: " + Arrays.toString(guest.splitNames));
                    if (guest.applicationInfo == null || original.applicationInfo == null) {
                        record("Launch blocked: application information is unavailable."); return;
                    }
                    record("Container ApplicationInfo split names: " + Arrays.toString(guest.applicationInfo.splitNames));
                    record("Original split paths: " + Arrays.toString(original.applicationInfo.splitSourceDirs));
                    record("Container split paths: " + Arrays.toString(guest.applicationInfo.splitSourceDirs));
                    record("Container native library directory: " + guest.applicationInfo.nativeLibraryDir);
                    String blocked = SplitImportCheck.check(original.splitNames, guest.splitNames,
                        guest.applicationInfo.splitNames, original.applicationInfo.sourceDir,
                        guest.applicationInfo.sourceDir, original.applicationInfo.splitSourceDirs,
                        guest.applicationInfo.splitSourceDirs);
                    if (blocked != null) { record("Launch blocked: " + blocked); return; }
                    if (guest.splitNames == null || guest.splitNames.length == 0) {
                        record("PackageInfo omitted split names; ApplicationInfo names and actual APK bytes validated.");
                    }
                    compatible = true;
                    record("Import, split names, APK readability and SHA-256 checks passed. This does not prove game startup or login.");
                } catch (PackageManager.NameNotFoundException missing) {
                    record("Original game is not installed/visible. Install it from its official listing.");
                } catch (Throwable failure) {
                    record("Import error: " + failure.getClass().getSimpleName() + ": " + failure.getMessage());
                } finally {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (isDestroyed()) return;
                            busy = false;
                            prepare.setEnabled(ProbeApplication.ready);
                            google.setEnabled(ProbeApplication.ready && !busy); microgSettings.setEnabled(ProbeApplication.ready && !busy); microgLogin.setEnabled(ProbeApplication.ready && !busy);
                            launch.setEnabled(compatible && android.os.SystemClock.elapsedRealtime() >= nextLaunchAt);
                        }
                    });
                }
            }
        });
    }

    private void setupGoogle() {
        if (busy || !ProbeApplication.ready) return;
        busy = true;
        google.setEnabled(false); microgSettings.setEnabled(false); microgLogin.setEnabled(false); prepare.setEnabled(false); launch.setEnabled(false);
        record("microG setup: bundled source-built login runtime and pinned Companion installed into this separate container. No phone Google apps/accounts are replaced or copied.");
        worker.execute(new Runnable() {
            @Override public void run() {
                try {
                    MicroGRuntime.setup(ProbeActivity.this, USER, new MicroGRuntime.Reporter() {
                        @Override public void report(String message) { record(message); }
                    });
                } catch (Throwable failure) {
                    record("microG setup failed: " + failure.getClass().getSimpleName());
                    StartupDiagnostics.failure("microG setup failed", failure);
                } finally {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (isDestroyed()) return;
                            busy = false;
                            google.setEnabled(ProbeApplication.ready); microgSettings.setEnabled(ProbeApplication.ready); microgLogin.setEnabled(ProbeApplication.ready);
                            prepare.setEnabled(ProbeApplication.ready);
                            launch.setEnabled(compatible && android.os.SystemClock.elapsedRealtime() >= nextLaunchAt);
                        }
                    });
                }
            }
        });
    }

    private void openMicroGSettings() {
        if (busy || !ProbeApplication.ready) return;
        busy = true;
        microgSettings.setEnabled(false); microgLogin.setEnabled(false); google.setEnabled(false); prepare.setEnabled(false); launch.setEnabled(false);
        worker.execute(new Runnable() {
            @Override public void run() {
                try {
                    if (!MicroGRuntime.ready(ProbeActivity.this, USER)) { record("Install bundled account services first; runtime bytes/metadata are not ready."); return; }
                    final android.content.ComponentName component = new android.content.ComponentName(MicroGRuntime.GMS, "org.microg.gms.ui.MainSettingsActivity");
                    if (BlackBoxCore.getBPackageManager().getActivityInfo(component, 0, USER) == null) { record("microG settings activity could not be resolved."); return; }
                    StartupDiagnostics.event("--- microG settings launch ---");
                    BlackBoxCore.get().stopPackage(MicroGRuntime.GMS, USER);
                    record("Restarted only container microG processes before settings launch; runtime files and account data retained.");
                    Intent target = new Intent().setComponent(component).setPackage(MicroGRuntime.GMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    BlackBoxCore.get().startActivity(target, USER);
                    record("microG settings launch dispatched; confirm its actual screen and Self-Check results.");
                } catch (Throwable failure) {
                    StartupDiagnostics.failure("microG settings failed", failure);
                    record("microG settings failed: " + failure.getClass().getSimpleName());
                } finally {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (isDestroyed()) return;
                            busy = false;
                            microgSettings.setEnabled(ProbeApplication.ready); microgLogin.setEnabled(ProbeApplication.ready); google.setEnabled(ProbeApplication.ready); prepare.setEnabled(ProbeApplication.ready);
                            launch.setEnabled(compatible && android.os.SystemClock.elapsedRealtime() >= nextLaunchAt);
                        }
                    });
                }
            }
        });
    }

    private void openMicroGLogin() {
        if (busy || !ProbeApplication.ready) return;
        busy = true;
        microgLogin.setEnabled(false); microgSettings.setEnabled(false); google.setEnabled(false); prepare.setEnabled(false); launch.setEnabled(false);
        worker.execute(new Runnable() {
            @Override public void run() {
                try {
                    if (!MicroGRuntime.ready(ProbeActivity.this, USER)) { record("Install bundled account services first."); return; }
                    MicroGReadiness.transport(new MicroGRuntime.Reporter() {
                        @Override public void report(String message) { record(message); }
                    });
                    android.content.ComponentName component = new android.content.ComponentName(MicroGRuntime.GMS, "org.microg.gms.auth.login.LoginActivity");
                    if (BlackBoxCore.getBPackageManager().getActivityInfo(component, 0, USER) == null) { record("Modified microG login activity is unavailable."); return; }
                    Intent target = new Intent().setComponent(component).setPackage(MicroGRuntime.GMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    StartupDiagnostics.event("--- Direct modified microG login launch ---");
                    int status = BlackBoxCore.getBActivityManager().startActivityAms(USER, target, null, null, null, -1, 0, null);
                    record("Modified microG login launch status=" + status + "; this is not authentication success.");
                } catch (Throwable failure) {
                    StartupDiagnostics.failure("microG login launch failed", failure);
                    record("microG login launch failed: " + failure.getClass().getSimpleName());
                } finally {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (isDestroyed()) return;
                            busy = false;
                            microgLogin.setEnabled(ProbeApplication.ready); microgSettings.setEnabled(ProbeApplication.ready); google.setEnabled(ProbeApplication.ready); prepare.setEnabled(ProbeApplication.ready);
                            launch.setEnabled(compatible && android.os.SystemClock.elapsedRealtime() >= nextLaunchAt);
                        }
                    });
                }
            }
        });
    }

    private void launchInside() {
        if (!compatible || busy || android.os.SystemClock.elapsedRealtime() < nextLaunchAt) return;
        nextLaunchAt = android.os.SystemClock.elapsedRealtime() + 45000;
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override public void run() {
                if (!isDestroyed()) launch.setEnabled(compatible && !busy);
            }
        }, 45000);
        busy = true; launch.setEnabled(false); prepare.setEnabled(false); google.setEnabled(false); microgSettings.setEnabled(false); microgLogin.setEnabled(false);
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override public void run() {
                if (!isDestroyed() && busy) record("Startup dispatch is still pending after 20 seconds. Share startup report remains available.");
            }
        }, 20000);
        final long attempt = System.currentTimeMillis();
        StartupDiagnostics.event("--- Full startup test attempt=" + attempt + " ---");
        record("Google sign-in must be tested inside this container; engine acceptance is not login success.");
        record("Launching the source-built replacement engine. It contains no Pine/SpaceCore dependency.");
        worker.execute(new Runnable() {
            @Override public void run() {
                try {
                    if (!MicroGRuntime.ready(ProbeActivity.this, USER)) { record("Install bundled account services first. Game launch blocked until runtime integrity and import checks pass."); return; }
                    CrashEvidence.capture(ProbeActivity.this);
                    String relayCheck = ServiceConnectionContractCheck.run();
                    record("Local service callback relay: " + relayCheck);
                    if (!relayCheck.equals("PASSED")) { record("Launch blocked: local Binder relay check failed."); return; }
                    StartupDiagnostics.event("Engine stopPackage entered");
                    BlackBoxCore.get().stopPackage(GAME, USER);
                    StartupDiagnostics.event("Engine stopPackage returned");
                    record("Stopped only the previous container game process; game data retained.");
                    StartupDiagnostics.event("Engine launch-intent resolution entered");
                    final Intent target = BlackBoxCore.getBPackageManager().getLaunchIntentForPackage(GAME, USER);
                    StartupDiagnostics.event("Engine launch-intent resolution returned");
                    record("Container launch intent: " + (target == null ? "missing" : target.getComponent()));
                    if (target == null) { record("Launch blocked: game activity could not be resolved."); return; }
                    StartupDiagnostics.event("--- New game launch attempt=" + attempt + " ---");
                    // SDK uses its application Context/explicit main Handler; blocking IPC stays off our UI thread.
                    boolean accepted = BlackBoxCore.get().launchApk(GAME, USER);
                    record("Engine launch accepted: " + accepted);
                    StartupDiagnostics.event("Engine launchApk returned; rendering is unverified");
                    record("Launch requested. Wait 45 seconds, then return and Share startup report.");
                } catch (Throwable failure) {
                    StartupDiagnostics.failure("Full startup test failed", failure);
                    record("Startup test error: " + failure.getClass().getSimpleName());
                    CrashEvidence.capture(ProbeActivity.this);
                } finally {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (isDestroyed()) return;
                            busy = false; google.setEnabled(ProbeApplication.ready); microgSettings.setEnabled(ProbeApplication.ready); microgLogin.setEnabled(ProbeApplication.ready); prepare.setEnabled(ProbeApplication.ready); launch.setEnabled(compatible && android.os.SystemClock.elapsedRealtime() >= nextLaunchAt);
                            renderReport();
                        }
                    });
                }
            }
        });
    }

    private void captureReport(final boolean shareWhenReady) {
        record("Collecting own-app exits and filtered crash evidence…");
        new Thread(new Runnable() {
            @Override public void run() {
                CrashEvidence.capture(ProbeActivity.this);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (isDestroyed()) return;
                        renderReport();
                        if (shareWhenReady) share();
                    }
                });
            }
        }, "capture-crash-evidence").start();
    }

    private String combinedReport() {
        String events = StartupDiagnostics.read();
        StringBuilder accountStages = new StringBuilder();
        for (String event : events.split("\n")) if (event.contains("Account flow:")) accountStages.append(event).append('\n');
        if (accountStages.length() > 12000) accountStages.delete(0, accountStages.length() - 12000);
        int marker = events.lastIndexOf("--- Full startup test attempt=");
        if (marker >= 0) events = events.substring(events.lastIndexOf('\n', marker) + 1);
        return journal.toString() + "\n--- Account/provider stages (no account contents) ---\n" + accountStages
            + "\n--- Latest startup attempt diagnostics ---\n" + events
            + "\n--- Consolidated crash evidence (history may include earlier builds) ---\n" + CrashEvidence.read("crash-evidence.txt");
    }

    private void renderReport() {
        if (log != null) log.setText(combinedReport());
    }

    @Override protected void onResume() {
        super.onResume();
        renderReport();
    }

    private void share() {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, combinedReport());
        try { startActivity(Intent.createChooser(intent, "Share startup report")); }
        catch (RuntimeException unavailable) { record("Sharing unavailable; select and copy the report."); }
    }

    @Override protected void onDestroy() {
        worker.shutdown();
        super.onDestroy();
    }
}
