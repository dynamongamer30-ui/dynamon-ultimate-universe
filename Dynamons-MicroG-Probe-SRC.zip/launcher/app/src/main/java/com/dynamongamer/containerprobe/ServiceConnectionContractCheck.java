package com.dynamongamer.containerprobe;

import android.app.IServiceConnection;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import top.niunaijun.blackbox.fake.delegate.ServiceConnectionDelegate;

/** On-device smoke check: no Android service is bound and no game state is changed. */
final class ServiceConnectionContractCheck {
    private static final String DESCRIPTOR = "android.app.IServiceConnection";

    static String run() {
        try {
            if (!check(false) || !check(true)) return "FAILED_PAYLOAD_OR_FLAGS";
            return "PASSED";
        } catch (Throwable failure) {
            StartupDiagnostics.failure("Local service callback relay check failed", failure);
            return "FAILED_" + failure.getClass().getSimpleName();
        }
    }

    private static boolean check(boolean useIncomingName) throws Exception {
        final ComponentName incoming = new ComponentName("local.test.proxy", "local.test.ProxyService");
        final ComponentName expected = useIncomingName ? incoming
            : new ComponentName("local.test.target", "local.test.TargetService");
        final IBinder service = new Binder();
        final boolean[] received = {false};
        Binder receiver = new Binder() {
            @Override protected boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
                data.enforceInterface(DESCRIPTOR);
                ComponentName name = data.readInt() == 0 ? null : ComponentName.CREATOR.createFromParcel(data);
                IBinder binder = data.readStrongBinder();
                boolean dead = data.readInt() != 0;
                int extraPlatformField = data.readInt();
                received[0] = code == IBinder.FIRST_CALL_TRANSACTION && expected.equals(name)
                    && binder == service && dead && extraPlatformField == 347
                    && flags == IBinder.FLAG_ONEWAY && data.dataAvail() == 0;
                return true;
            }
        };
        Intent intent = new Intent();
        if (!useIncomingName) intent.setComponent(expected);
        IServiceConnection proxy = ServiceConnectionDelegate.createProxy(IServiceConnection.Stub.asInterface(receiver), intent);
        Parcel data = Parcel.obtain();
        try {
            data.writeInterfaceToken(DESCRIPTOR);
            data.writeInt(1); incoming.writeToParcel(data, 0);
            data.writeStrongBinder(service); data.writeInt(1); data.writeInt(347);
            boolean accepted = proxy.asBinder().transact(IBinder.FIRST_CALL_TRANSACTION, data, null, IBinder.FLAG_ONEWAY);
            return accepted && received[0];
        } finally { data.recycle(); }
    }
}
