package com.dynamongamer.containerprobe;

import android.app.Activity;
import android.app.Application;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import java.lang.ref.WeakReference;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/** Read-only metadata and stack frames. Never reads page content, credentials or cookies. */
final class MicroGLoginDiagnostics {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final ScheduledExecutorService WORKER = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread thread = new Thread(r, "microg-stage-observer");
        thread.setDaemon(true);
        return thread;
    });
    private static final AtomicInteger GENERATION = new AtomicInteger();

    static void register(Application application) {
        application.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
            public void onActivityCreated(Activity activity, Bundle state) {}
            public void onActivityStarted(Activity activity) {}
            public void onActivityResumed(Activity activity) {
                if (!"org.microg.gms.auth.login.LoginActivity".equals(activity.getClass().getName())) return;
                int generation = GENERATION.incrementAndGet();
                WeakReference<Activity> reference = new WeakReference<>(activity);
                for (int seconds : new int[]{2, 10, 25, 45}) {
                    WORKER.schedule(() -> sample(reference, generation, seconds), seconds, TimeUnit.SECONDS);
                }
            }
            public void onActivityPaused(Activity activity) {}
            public void onActivityStopped(Activity activity) {}
            public void onActivitySaveInstanceState(Activity activity, Bundle state) {}
            public void onActivityDestroyed(Activity activity) {
                if ("org.microg.gms.auth.login.LoginActivity".equals(activity.getClass().getName())) GENERATION.incrementAndGet();
            }
        });
    }

    private static void sample(WeakReference<Activity> reference, int generation, int seconds) {
        if (generation != GENERATION.get() || reference.get() == null) return;
        AtomicBoolean responded = new AtomicBoolean();
        MAIN.post(() -> {
            Activity activity = reference.get();
            if (generation != GENERATION.get() || activity == null || activity.isDestroyed()) return;
            responded.set(true);
            try {
                WebView web = find(activity.getWindow().getDecorView(), 0, new int[]{0});
                if (web == null) { event("WEBVIEW_ABSENT sample=" + seconds); return; }
                event("WEBVIEW sample=" + seconds + " endpoint=" + endpoint(web.getUrl())
                    + " progress=" + web.getProgress() + " visibility=" + web.getVisibility()
                    + " javascript=" + web.getSettings().getJavaScriptEnabled());
            } catch (Throwable failure) { event("INSPECTION_ERROR class=" + failure.getClass().getName()); }
        });
        WORKER.schedule(() -> {
            if (generation != GENERATION.get()) return;
            event("MAIN_RESPONDED sample=" + seconds + " value=" + responded.get());
            try {
                int count = 0;
                for (Map.Entry<Thread, StackTraceElement[]> entry : Thread.getAllStackTraces().entrySet()) {
                    boolean relevant = entry.getKey() == Looper.getMainLooper().getThread();
                    for (StackTraceElement frame : entry.getValue()) {
                        if (frame.getClassName().startsWith("org.microg.gms.auth.login.")
                            || frame.getClassName().startsWith("org.microg.gms.checkin.")) relevant = true;
                    }
                    if (!relevant || ++count > 8) continue;
                    event("THREAD sample=" + seconds + " main=" + (entry.getKey() == Looper.getMainLooper().getThread())
                        + " state=" + entry.getKey().getState().name());
                    int frames = 0;
                    for (StackTraceElement frame : entry.getValue()) {
                        if (++frames > 24) break;
                        event("at " + frame.getClassName() + "." + frame.getMethodName());
                    }
                }
            } catch (Throwable failure) { event("STACK_ERROR class=" + failure.getClass().getName()); }
        }, 1, TimeUnit.SECONDS);
    }

    static String endpoint(String value) {
        if (value == null || value.isEmpty() || "about:blank".equals(value)) return "EMPTY";
        Uri uri = Uri.parse(value);
        if ("accounts.google.com".equals(uri.getHost())) return "GOOGLE_ACCOUNTS";
        if ("android.clients.google.com".equals(uri.getHost())) return "GOOGLE_ANDROID";
        return "OTHER";
    }
    private static void event(String value) { StartupDiagnostics.event("Account flow: LOGIN_OBSERVER " + value); }
    private static WebView find(View view, int depth, int[] visits) {
        if (view == null || depth > 24 || ++visits[0] > 512) return null;
        if (view instanceof WebView) return (WebView) view;
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                WebView web = find(group.getChildAt(i), depth + 1, visits);
                if (web != null) return web;
            }
        }
        return null;
    }
}
