package com.dynamongamer.containerprobe;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.security.MessageDigest;

/** Bounded, atomic runtime download with a pinned whole-file hash. */
final class VerifiedRuntimeFile {
    interface Progress { void update(long count); }
    private VerifiedRuntimeFile() {}

    static boolean matches(File file, long size, String expected) throws Exception {
        if (!file.isFile() || file.length() != size) return false;
        MessageDigest hash = MessageDigest.getInstance("SHA-256");
        byte[] buffer = new byte[65536];
        try (InputStream input = new FileInputStream(file)) {
            int count;
            while ((count = input.read(buffer)) != -1) hash.update(buffer, 0, count);
        }
        return hex(hash.digest()).equals(expected);
    }

    static void receive(InputStream input, File destination, long size, String expected, Progress progress) throws Exception {
        File partial = new File(destination.getPath() + ".part");
        boolean complete = false;
        try {
            MessageDigest hash = MessageDigest.getInstance("SHA-256");
            long total = 0;
            byte[] buffer = new byte[65536];
            try (FileOutputStream output = new FileOutputStream(partial)) {
                int count;
                while ((count = input.read(buffer)) != -1) {
                    if (Thread.currentThread().isInterrupted()) throw new java.io.InterruptedIOException();
                    total += count;
                    if (total > size) throw new java.io.IOException("Runtime exceeds pinned size");
                    output.write(buffer, 0, count);
                    hash.update(buffer, 0, count);
                    progress.update(total);
                }
                output.getFD().sync();
            }
            if (total != size || !hex(hash.digest()).equals(expected)) throw new java.io.IOException("Runtime integrity check failed");
            java.nio.file.Files.move(partial.toPath(), destination.toPath(),
                java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            complete = true;
        } finally {
            if (!complete) partial.delete();
        }
    }

    private static String hex(byte[] bytes) {
        StringBuilder result = new StringBuilder();
        for (byte value : bytes) result.append(String.format(java.util.Locale.ROOT, "%02x", value & 255));
        return result.toString();
    }
}
