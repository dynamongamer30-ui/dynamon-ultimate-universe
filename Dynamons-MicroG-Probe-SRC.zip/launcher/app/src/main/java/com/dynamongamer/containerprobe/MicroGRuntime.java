package com.dynamongamer.containerprobe;

import android.content.Context;
import android.content.pm.PackageInfo;
import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.core.system.pm.MicrogTrustPolicy;
import top.niunaijun.blackbox.entity.pm.InstallResult;

/** Pinned companion and own-built account runtime. Guest service compatibility; original game unchanged. */
final class MicroGRuntime {
    interface Reporter { void report(String message); }
    static final String GMS = "com.google.android.gms";
    static final String RELEASE = "v0.3.17.252432";
    private static final Artifact[] ARTIFACTS = {
        new Artifact("com.android.vending", "com.android.vending-84022634.apk", 4210169L,
            "9b8616011cc8f026bcbbe094df850794abb9d6d9f23214d7a8f8c4d1033ea012", 84022634L),
        new Artifact(GMS, "dynamons-account-services-7.2.1.apk", MicrogTrustPolicy.BUNDLED_SIZE,
            MicrogTrustPolicy.BUNDLED_SHA256, MicrogTrustPolicy.BUNDLED_VERSION)
    };

    private static final class Artifact {
        final String pkg, name, sha;
        final long size, version;
        Artifact(String pkg, String name, long size, String sha, long version) {
            this.pkg = pkg; this.name = name; this.size = size; this.sha = sha; this.version = version;
        }
    }

    private MicroGRuntime() {}

    static boolean setup(Context host, int user, Reporter reporter) throws Exception {
        File directory = new File(host.getFilesDir(), "official-microg");
        if (!directory.isDirectory() && !directory.mkdirs()) throw new java.io.IOException("Runtime storage unavailable");
        // Fetch and verify BOTH artifacts before changing container package metadata.
        for (Artifact artifact : ARTIFACTS) {
            File apk = new File(directory, artifact.name);
            if (!VerifiedRuntimeFile.matches(apk, artifact.size, artifact.sha)) {
                if (GMS.equals(artifact.pkg)) {
                    reporter.report("Copying bundled account runtime…");
                    try (InputStream input = host.getAssets().open("account-services.apk")) {
                        VerifiedRuntimeFile.receive(input, apk, artifact.size, artifact.sha, count -> {});
                    }
                } else download(artifact, apk, reporter);
            }
            reporter.report(artifact.pkg + ": pinned APK SHA-256 verified.");
        }
        boolean gameStopped = false;
        for (Artifact artifact : ARTIFACTS) {
            File apk = new File(directory, artifact.name);
            PackageInfo source = host.getPackageManager().getPackageArchiveInfo(apk.getPath(), 0);
            if (source == null || !artifact.pkg.equals(source.packageName) || source.versionCode != artifact.version) throw new java.io.IOException("Runtime package mismatch");
            PackageInfo guest = BlackBoxCore.getBPackageManager().getPackageInfo(artifact.pkg, 0, user);
            if (check(artifact, apk, guest) != null) {
                if (!gameStopped) { BlackBoxCore.get().stopPackage("com.funtomic.dynamons3", user); gameStopped = true; reporter.report("Stopped only this microG-container game process before runtime import; game data retained."); }
                BlackBoxCore.get().stopPackage(artifact.pkg, user);
                InstallResult result = BlackBoxCore.get().installPackageAsUser(apk, user);
                if (result == null || !result.success) {
                    reporter.report(artifact.pkg + ": import failed; no data cleared.");
                    return false;
                }
                guest = null;
                for (int retry = 0; retry < 4 && guest == null; retry++) {
                    if (retry > 0) Thread.sleep(150);
                    guest = BlackBoxCore.getBPackageManager().getPackageInfo(artifact.pkg, 0, user);
                }
            }
            String failure = check(artifact, apk, guest);
            if (failure != null) { reporter.report(artifact.pkg + ": validation failed: " + failure); return false; }
            reporter.report(artifact.pkg + ": container APK bytes validated; version=" + guest.versionName);
        }
        reporter.report("microG runtime imported. Use Prepare & sign in to open the genuine Google account page through the modified microG runtime. Authentication remains unverified.");
        reporter.report("Guest service compatibility is limited to these exact pinned APKs; the account runtime is our source-built Morphe fork. Original-game signing identity is unchanged; no OS privileged permissions are granted.");
        return true;
    }

    static boolean ready(Context host, int user) throws Exception {
        for (Artifact artifact : ARTIFACTS) {
            File apk = new File(new File(host.getFilesDir(), "official-microg"), artifact.name);
            if (!VerifiedRuntimeFile.matches(apk, artifact.size, artifact.sha)
                || check(artifact, apk, BlackBoxCore.getBPackageManager().getPackageInfo(artifact.pkg, 0, user)) != null) return false;
        }
        return true;
    }

    private static String check(Artifact artifact, File apk, PackageInfo guest) {
        if (guest == null || guest.applicationInfo == null || !artifact.pkg.equals(guest.packageName) || guest.versionCode != artifact.version) return "metadata unavailable";
        return SplitImportCheck.check(null, guest.splitNames, guest.applicationInfo.splitNames,
            apk.getPath(), guest.applicationInfo.sourceDir, null, guest.applicationInfo.splitSourceDirs);
    }

    private static void download(final Artifact artifact, File apk, final Reporter reporter) throws Exception {
        URL url = new URL("https://github.com/microg/GmsCore/releases/download/" + RELEASE + "/" + artifact.name);
        HttpURLConnection connection = null;
        try {
            for (int redirect = 0; redirect <= 5; redirect++) {
                if (!"https".equals(url.getProtocol()) || !(url.getHost().equals("github.com")
                    || url.getHost().equals("release-assets.githubusercontent.com")
                    || url.getHost().equals("objects.githubusercontent.com"))) throw new java.io.IOException("Unexpected runtime download origin");
                connection = (HttpURLConnection) url.openConnection();
                connection.setInstanceFollowRedirects(false);
                connection.setConnectTimeout(20000); connection.setReadTimeout(30000);
                connection.setRequestProperty("Accept-Encoding", "identity");
                int status = connection.getResponseCode();
                if (status == 301 || status == 302 || status == 303 || status == 307 || status == 308) {
                    String location = connection.getHeaderField("Location");
                    connection.disconnect(); connection = null;
                    if (location == null) throw new java.io.IOException("Missing runtime redirect");
                    url = new URL(url, location);
                    continue;
                }
                if (status != 200) { reporter.report("Runtime download HTTP status=" + status); throw new java.io.IOException("Runtime download failed"); }
                final int[] lastProgress = {-1};
                reporter.report("Downloading " + artifact.name + " (" + artifact.size + " bytes)…");
                try (InputStream input = connection.getInputStream()) {
                    VerifiedRuntimeFile.receive(input, apk, artifact.size, artifact.sha, new VerifiedRuntimeFile.Progress() {
                        @Override public void update(long count) {
                            int step = (int)(count * 10 / artifact.size);
                            if (step != lastProgress[0]) { lastProgress[0] = step; reporter.report(artifact.pkg + ": download " + step * 10 + "%"); }
                        }
                    });
                }
                return;
            }
            throw new java.io.IOException("Too many runtime redirects");
        } finally {
            if (connection != null) connection.disconnect();
        }
    }
}
