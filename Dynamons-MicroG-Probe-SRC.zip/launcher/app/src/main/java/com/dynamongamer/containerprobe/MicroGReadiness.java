package com.dynamongamer.containerprobe;

import android.accounts.AccountManager;
import android.accounts.AuthenticatorDescription;
import android.app.Application;
import android.content.Context;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;

/** Separates transport, registration, accounts and game SDK acceptance. No login-success claim. */
final class MicroGReadiness {
    static void observe(Application application, boolean microg) {
        Thread thread = new Thread(() -> {
            try {
                if (microg) {
                    AccountManager manager = AccountManager.get(application);
                    boolean found = false;
                    for (AuthenticatorDescription auth : manager.getAuthenticatorTypes()) if ("com.google".equals(auth.type)) found = true;
                    event("AUTHENTICATOR_PRESENT=" + found);
                    event("ACCOUNT_PRESENT=" + (manager.getAccountsByType("com.google").length > 0));
                    Class<?> state = application.getClassLoader().loadClass("org.microg.gms.checkin.LastCheckinInfo");
                    Object info = state.getMethod("read", Context.class).invoke(null, application);
                    Object id = state.getMethod("getAndroidId").invoke(info);
                    event("CHECKIN_PRESENT=" + (id instanceof Number && ((Number) id).longValue() != 0));
                } else {
                    Class<?> api = application.getClassLoader().loadClass("com.google.android.gms.common.GoogleApiAvailability");
                    Object instance = api.getMethod("getInstance").invoke(null);
                    Method check = api.getMethod("isGooglePlayServicesAvailable", Context.class);
                    Object result = check.invoke(instance, application);
                    event("GAME_SDK_AVAILABILITY=" + (result instanceof Number ? ((Number) result).intValue() : "UNKNOWN"));
                }
            } catch (Throwable failure) { event("METADATA_UNAVAILABLE class=" + failure.getClass().getName()); }
        }, "microg-readiness");
        thread.setDaemon(true);
        thread.start();
    }

    static void transport(MicroGRuntime.Reporter reporter) {
        Thread thread = new Thread(() -> {
            probe("GOOGLE_ACCOUNTS", "https://accounts.google.com/", reporter);
            probe("GOOGLE_CHECKIN", "https://android.clients.google.com/checkin", reporter);
        }, "microg-transport-check");
        thread.setDaemon(true);
        thread.start();
    }

    private static void probe(String label, String endpoint, MicroGRuntime.Reporter reporter) {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(endpoint).openConnection();
            connection.setConnectTimeout(8000);
            connection.setReadTimeout(8000);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestMethod("HEAD");
            int status = connection.getResponseCode();
            // Any HTTP response shows DNS/TLS/HTTP reachability, not successful check-in/authentication.
            reporter.report("Transport " + label + ": HTTP=" + status + "; authentication not tested.");
        } catch (Exception failure) {
            reporter.report("Transport " + label + ": failed=" + failure.getClass().getSimpleName());
        } finally { if (connection != null) connection.disconnect(); }
    }
    private static void event(String message) { StartupDiagnostics.event("Account flow: READINESS " + message); }
}
