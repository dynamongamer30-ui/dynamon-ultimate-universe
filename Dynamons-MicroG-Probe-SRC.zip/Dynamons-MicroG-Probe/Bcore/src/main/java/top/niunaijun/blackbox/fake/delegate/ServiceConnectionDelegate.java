package top.niunaijun.blackbox.fake.delegate;

import android.app.IServiceConnection;
import android.content.ComponentName;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import android.os.Parcel;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;



public class ServiceConnectionDelegate extends IServiceConnection.Stub {
    private static final Map<IBinder, ServiceConnectionDelegate> sServiceConnectDelegate = new ConcurrentHashMap<>();
    private final IServiceConnection mConn;
    private final ComponentName mComponentName;

    private ServiceConnectionDelegate(IServiceConnection mConn, ComponentName targetComponent) {
        this.mConn = mConn;
        this.mComponentName = targetComponent;
    }

    public static ServiceConnectionDelegate getDelegate(IBinder iBinder) {
        return sServiceConnectDelegate.get(iBinder);
    }

    public static IServiceConnection createProxy(IServiceConnection base, Intent intent) {
        final IBinder iBinder = base.asBinder();
        ServiceConnectionDelegate delegate = sServiceConnectDelegate.get(iBinder);
        if (delegate == null) {
            try {
                iBinder.linkToDeath(new IBinder.DeathRecipient() {
                    @Override
                    public void binderDied() {
                        sServiceConnectDelegate.remove(iBinder);
                        iBinder.unlinkToDeath(this, 0);
                    }
                }, 0);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
            delegate = new ServiceConnectionDelegate(base, intent.getComponent());
            sServiceConnectDelegate.put(iBinder, delegate);
        }
        return delegate;
    }

    private static final String DESCRIPTOR = "android.app.IServiceConnection";

    /**
     * Platform Stub classes come from the boot class loader, not our compiled AIDL.
     * Relay the wire transaction directly so an old generated Proxy cannot dispatch
     * an incompatible abstract Java method. Preserve the binder, death flag and any
     * platform-specific fields following ComponentName, along with transaction flags.
     */
    @Override public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
        if (code != IBinder.FIRST_CALL_TRANSACTION) return super.onTransact(code, data, reply, flags);
        data.enforceInterface(DESCRIPTOR);
        ComponentName original = data.readInt() == 0 ? null : ComponentName.CREATOR.createFromParcel(data);
        ComponentName target = mComponentName == null ? original : mComponentName;
        Parcel forwarded = Parcel.obtain();
        try {
            forwarded.writeInterfaceToken(DESCRIPTOR);
            if (target == null) forwarded.writeInt(0);
            else { forwarded.writeInt(1); target.writeToParcel(forwarded, 0); }
            forwarded.appendFrom(data, data.dataPosition(), data.dataAvail());
            return mConn.asBinder().transact(code, forwarded, reply, flags);
        } finally { forwarded.recycle(); }
    }

    @Override public void connected(ComponentName name, IBinder service, boolean dead) throws RemoteException {
        Parcel data = Parcel.obtain();
        try {
            data.writeInterfaceToken(DESCRIPTOR);
            ComponentName target = mComponentName == null ? name : mComponentName;
            if (target == null) data.writeInt(0);
            else { data.writeInt(1); target.writeToParcel(data, 0); }
            data.writeStrongBinder(service);
            data.writeInt(dead ? 1 : 0);
            mConn.asBinder().transact(IBinder.FIRST_CALL_TRANSACTION, data, null, IBinder.FLAG_ONEWAY);
        } finally { data.recycle(); }
    }
}
