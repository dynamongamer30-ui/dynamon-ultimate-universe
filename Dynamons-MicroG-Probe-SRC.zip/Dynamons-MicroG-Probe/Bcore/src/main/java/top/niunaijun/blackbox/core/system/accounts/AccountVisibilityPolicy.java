package top.niunaijun.blackbox.core.system.accounts;

/** Android visibility values: explicit user grants/denials win over legacy defaults. */
public final class AccountVisibilityPolicy {
    private AccountVisibilityPolicy() {}
    public static boolean readable(int value) { return value == 1 || value == 2; }
    public static boolean matches(String requested, String actual) { return requested == null || requested.equals(actual); }
    public static int resolve(Integer explicit, boolean authenticatorOwner, Integer legacy) {
        if (explicit != null && explicit != 0) return explicit;
        if (authenticatorOwner) return 1;
        if (legacy != null && legacy != 0) return legacy;
        return 3;
    }
}
