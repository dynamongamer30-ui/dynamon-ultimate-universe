package top.niunaijun.blackbox.app;
import java.lang.reflect.Method;
public final class ProviderInstallContract {
    private ProviderInstallContract() {}
    public static Method find(Class<?> owner, Class<?> context, Class<?> provider) throws NoSuchMethodException {
        for (Class<?> type = owner; type != null; type = type.getSuperclass()) {
            for (Method method : type.getDeclaredMethods()) {
                Class<?>[] p = method.getParameterTypes();
                if (method.getName().equals("installProvider") && p.length == 6
                    && p[0].isAssignableFrom(context) && p[2] == provider
                    && p[3] == boolean.class && p[4] == boolean.class && p[5] == boolean.class) return method;
            }
        }
        throw new NoSuchMethodException("Supported ActivityThread.installProvider contract unavailable");
    }
}
