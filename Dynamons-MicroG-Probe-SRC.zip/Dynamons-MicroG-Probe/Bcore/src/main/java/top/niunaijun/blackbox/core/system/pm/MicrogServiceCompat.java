package top.niunaijun.blackbox.core.system.pm;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.os.Build;
import android.os.Parcel;
import java.io.File;
import java.io.FileInputStream;
import java.lang.reflect.Constructor;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;
import top.niunaijun.blackbox.core.system.accounts.AccountFlowObserver;

/** Guest-only service compatibility. Real APK bytes and original-game signing metadata never change. */
public final class MicrogServiceCompat {
    // Public compatibility certificate declared by the official microG runtime, not a private key.
    private static final Signature EXPECTED = new Signature("308204433082032ba003020102020900c2e08746644a308d300d06092a864886f70d01010405003074310b3009060355040613025553311330110603550408130a43616c69666f726e6961311630140603550407130d4d6f756e7461696e205669657731143012060355040a130b476f6f676c6520496e632e3110300e060355040b1307416e64726f69643110300e06035504031307416e64726f6964301e170d3038303832313233313333345a170d3336303130373233313333345a3074310b3009060355040613025553311330110603550408130a43616c69666f726e6961311630140603550407130d4d6f756e7461696e205669657731143012060355040a130b476f6f676c6520496e632e3110300e060355040b1307416e64726f69643110300e06035504031307416e64726f696430820120300d06092a864886f70d01010105000382010d00308201080282010100ab562e00d83ba208ae0a966f124e29da11f2ab56d08f58e2cca91303e9b754d372f640a71b1dcb130967624e4656a7776a92193db2e5bfb724a91e77188b0e6a47a43b33d9609b77183145ccdf7b2e586674c9e1565b1f4c6a5955bff251a63dabf9c55c27222252e875e4f8154a645f897168c0b1bfc612eabf785769bb34aa7984dc7e2ea2764cae8307d8c17154d7ee5f64a51a44a602c249054157dc02cd5f5c0e55fbef8519fbe327f0b1511692c5a06f19d18385f5c4dbc2d6b93f68cc2979c70e18ab93866b3bd5db8999552a0e3b4c99df58fb918bedc182ba35e003c1b4b10dd244a8ee24fffd333872ab5221985edab0fc0d0b145b6aa192858e79020103a381d93081d6301d0603551d0e04160414c77d8cc2211756259a7fd382df6be398e4d786a53081a60603551d2304819e30819b8014c77d8cc2211756259a7fd382df6be398e4d786a5a178a4763074310b3009060355040613025553311330110603550408130a43616c69666f726e6961311630140603550407130d4d6f756e7461696e205669657731143012060355040a130b476f6f676c6520496e632e3110300e060355040b1307416e64726f69643110300e06035504031307416e64726f6964820900c2e08746644a308d300c0603551d13040530030101ff300d06092a864886f70d010104050003820101006dd252ceef85302c360aaace939bcff2cca904bb5d7a1661f8ae46b2994204d0ff4a68c7ed1a531ec4595a623ce60763b167297a7ae35712c407f208f0cb109429124d7b106219c084ca3eb3f9ad5fb871ef92269a8be28bf16d44c8d9a08e6cb2f005bb3fe2cb96447e868e731076ad45b33f6009ea19c161e62641aa99271dfd5228c5c587875ddb7f452758d661f6cc0cccb7352e424cc4365c523532f7325137593c4ae341f4db41edda0d0b1071a7c440f0fe9ea01cb627ca674369d084bd2fd911ff06cdbf2cfa10dc0f893ae35762919048c7efc64c7144178342f70581c9de573af55b390dd7fdb9418631895d5f759f30112687ff621410c069308a");
    private static final Map<String, String> VERIFIED = new HashMap<>();
    private static final java.util.Set<String> REPORTED = new java.util.HashSet<>();
    private MicrogServiceCompat() {}
    public static synchronized boolean trusted(PackageInfo info) {
        if (info == null || !MicrogTrustPolicy.candidate(info.packageName) || info.applicationInfo == null) return false;
        String path = info.applicationInfo.sourceDir;
        if (path == null) return false;
        File file = new File(path);
        if (!("com.google.android.gms".equals(info.packageName) && info.versionCode == 252432034 && file.length() == 108113833L)
            && !("com.android.vending".equals(info.packageName) && info.versionCode == 84022634 && file.length() == 4210169L)) return false;
        String stamp = info.packageName + ":" + info.versionCode + ":" + file.length() + ":" + file.lastModified();
        if (stamp.equals(VERIFIED.get(path))) return true;
        try (FileInputStream input = new FileInputStream(file)) {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = new byte[65536];
            int count;
            while ((count = input.read(bytes)) != -1) digest.update(bytes, 0, count);
            StringBuilder hex = new StringBuilder();
            for (byte value : digest.digest()) hex.append(String.format("%02x", value & 255));
            if (!MicrogTrustPolicy.trusted(info.packageName, info.versionCode, file.length(), hex.toString())) return false;
            VERIFIED.put(path, stamp);
            return true;
        } catch (Exception failure) { return false; }
    }
    public static PackageInfo view(PackageInfo real, int flags) {
        if (!trusted(real)) return real;
        Parcel parcel = Parcel.obtain();
        PackageInfo copy;
        try { real.writeToParcel(parcel, 0); parcel.setDataPosition(0); copy = PackageInfo.CREATOR.createFromParcel(parcel); }
        finally { parcel.recycle(); }
        if ((flags & PackageManager.GET_SIGNATURES) != 0) copy.signatures = new Signature[]{EXPECTED};
        if (copy.requestedPermissions != null && copy.requestedPermissionsFlags != null) {
            for (int i = 0; i < Math.min(copy.requestedPermissions.length, copy.requestedPermissionsFlags.length); i++)
                if ("android.permission.FAKE_PACKAGE_SIGNATURE".equals(copy.requestedPermissions[i]))
                    copy.requestedPermissionsFlags[i] |= PackageInfo.REQUESTED_PERMISSION_GRANTED;
        }
        if (Build.VERSION.SDK_INT >= 28 && (flags & PackageManager.GET_SIGNING_CERTIFICATES) != 0) {
            try { copy.signingInfo = signingInfo(); }
            catch (ReflectiveOperationException failure) {
                AccountFlowObserver.event(AccountFlowObserver.Stage.SERVICE_COMPAT_FAILED);
                return real;
            }
        }
        synchronized (REPORTED) {
            if (REPORTED.add(real.packageName)) AccountFlowObserver.event(AccountFlowObserver.Stage.SERVICE_COMPAT_APPLIED);
        }
        return copy;
    }
    private static SigningInfo signingInfo() throws ReflectiveOperationException {
        Class<?> details;
        try { details = Class.forName("android.content.pm.SigningDetails"); }
        catch (ClassNotFoundException old) { details = Class.forName("android.content.pm.PackageParser$SigningDetails"); }
        Constructor<?> constructor = details.getDeclaredConstructor(Signature[].class, int.class);
        constructor.setAccessible(true);
        Object value = constructor.newInstance(new Signature[]{EXPECTED}, 1);
        Constructor<SigningInfo> info = SigningInfo.class.getDeclaredConstructor(details);
        info.setAccessible(true);
        return info.newInstance(value);
    }
    public static boolean matches(byte[] certificate, int type) {
        try {
            byte[] expected = type == PackageManager.CERT_INPUT_SHA256
                ? MessageDigest.getInstance("SHA-256").digest(EXPECTED.toByteArray())
                : type == PackageManager.CERT_INPUT_RAW_X509 ? EXPECTED.toByteArray() : null;
            return expected != null && certificate != null && MessageDigest.isEqual(expected, certificate);
        } catch (Exception failure) { return false; }
    }
}
