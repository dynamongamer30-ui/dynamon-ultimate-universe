package top.niunaijun.blackbox.fake.service;

import android.content.Context;
import java.lang.reflect.Method;
import black.android.net.BRIConnectivityManagerStub;
import black.android.os.BRServiceManager;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.fake.hook.BinderInvocationStub;

/** Uses the actual host transport. No fabricated network, DNS, capabilities or success. */
public class IConnectivityManagerProxy extends BinderInvocationStub {
    public IConnectivityManagerProxy() { super(BRServiceManager.get().getService(Context.CONNECTIVITY_SERVICE)); }
    @Override protected Object getWho() {
        return BRIConnectivityManagerStub.get().asInterface(BRServiceManager.get().getService(Context.CONNECTIVITY_SERVICE));
    }
    @Override protected void inject(Object base, Object proxy) { replaceSystemService(Context.CONNECTIVITY_SERVICE); }
    @Override public boolean isBadEnv() { return false; }
    @Override public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        ServiceInvocationContract.fixCaller(method.getName(), args, BlackBoxCore.getAppPackageName(),
            BlackBoxCore.getBUid(), BlackBoxCore.getHostPkg(), BlackBoxCore.getHostUid());
        return ServiceInvocationContract.invoke(getBase(), method, args);
    }
}
