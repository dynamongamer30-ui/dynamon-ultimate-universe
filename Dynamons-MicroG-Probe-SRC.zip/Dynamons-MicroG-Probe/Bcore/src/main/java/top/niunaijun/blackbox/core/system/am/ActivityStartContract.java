package top.niunaijun.blackbox.core.system.am;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/** Android 11+ adds callingFeatureId before Intent; preserves the actual launch result. */
public final class ActivityStartContract {
    private ActivityStartContract() {}
    public static int invoke(Object manager, Class<?> intentType, Object caller, String pkg, Object intent,
            String resolvedType, Object resultTo, String resultWho, int requestCode, int flags, Object options) throws Throwable {
        for (int width : new int[]{11, 10}) {
            for (Method method : manager.getClass().getMethods()) {
                Class<?>[] p = method.getParameterTypes();
                int intentIndex = width == 11 ? 3 : 2;
                if (!method.getName().equals("startActivity") || p.length != width || p[intentIndex] != intentType) continue;
                Object[] args = width == 11
                    ? new Object[]{caller, pkg, null, intent, resolvedType, resultTo, resultWho, requestCode, flags, null, options}
                    : new Object[]{caller, pkg, intent, resolvedType, resultTo, resultWho, requestCode, flags, null, options};
                try {
                    method.setAccessible(true);
                    Object result = method.invoke(manager, args);
                    if (!(result instanceof Number)) throw new IllegalStateException("Missing activity launch status");
                    return ((Number) result).intValue();
                } catch (InvocationTargetException failure) { throw failure.getCause(); }
            }
        }
        throw new NoSuchMethodException("Supported startActivity contract unavailable");
    }
}
