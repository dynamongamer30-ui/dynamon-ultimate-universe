package top.niunaijun.blackbox.app;

/** Explicit component intents need not also set Intent.package. */
public final class LaunchPackageResolver {
    private LaunchPackageResolver() {}
    public static String resolve(String packageName, String componentPackage) {
        return packageName != null ? packageName : componentPackage;
    }
}
