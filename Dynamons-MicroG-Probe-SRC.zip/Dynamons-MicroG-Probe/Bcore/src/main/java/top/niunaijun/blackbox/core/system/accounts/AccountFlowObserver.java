package top.niunaijun.blackbox.core.system.accounts;

/** Stage-only diagnostics. No account names, tokens, response bundles or passwords. */
public final class AccountFlowObserver {
    public enum Stage { CACHE_REFRESHED, DISCOVERY, ADD_REQUEST, BIND_REQUEST, BIND_FAILED,
        SERVICE_CONNECTED, LOGIN_INTENT_RETURNED, RESULT_RETURNED, ERROR_RETURNED, TIMEOUT,
        SETTINGS_PROVIDER_INSTALL, SETTINGS_PROVIDER_INSTALLED, SETTINGS_PROVIDER_FAILED }
    public interface Sink { void event(Stage stage); }
    private static volatile Sink sink;
    private AccountFlowObserver() {}
    public static void setSink(Sink value) { sink = value; }
    public static void event(Stage stage) {
        Sink target = sink;
        if (target != null) try { target.event(stage); } catch (RuntimeException ignored) { /* diagnostic failure must not alter login */ }
    }
}
