package top.niunaijun.blackbox.core;

/** Framework provider checks operate on the real Binder caller, not the guest app ID. */
public final class ProviderIdentityPolicy {
    private ProviderIdentityPolicy() {}
    public static boolean requiresPhysicalUid(StackTraceElement[] stack) {
        for (StackTraceElement frame : stack) {
            String owner = frame.getClassName();
            if (owner.equals("android.content.ContentProvider")
                || owner.equals("android.content.ContentProvider$Transport")
                || owner.equals("android.content.AttributionSource")) return true;
        }
        return false;
    }
}
