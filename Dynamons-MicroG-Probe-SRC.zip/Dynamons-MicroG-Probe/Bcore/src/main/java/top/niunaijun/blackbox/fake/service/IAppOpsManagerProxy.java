package top.niunaijun.blackbox.fake.service;

import android.app.AppOpsManager;
import android.content.Context;
import java.lang.reflect.Method;
import black.android.app.BRAppOpsManager;
import black.android.os.BRServiceManager;
import black.com.android.internal.app.BRIAppOpsServiceStub;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.fake.hook.BinderInvocationStub;
import top.niunaijun.blackbox.utils.compat.ContextCompat;

/** Preserve platform decisions and object return types; do not turn denials into success. */
public class IAppOpsManagerProxy extends BinderInvocationStub {
    public IAppOpsManagerProxy() { super(BRServiceManager.get().getService(Context.APP_OPS_SERVICE)); }
    @Override protected Object getWho() {
        return BRIAppOpsServiceStub.get().asInterface(BRServiceManager.get().getService(Context.APP_OPS_SERVICE));
    }
    @Override protected void inject(Object base, Object proxy) {
        AppOpsManager manager = (AppOpsManager) BlackBoxCore.getContext().getSystemService(Context.APP_OPS_SERVICE);
        if (manager != null && BRAppOpsManager.get(manager)._check_mService() != null)
            BRAppOpsManager.get(manager)._set_mService(proxy);
        replaceSystemService(Context.APP_OPS_SERVICE);
    }
    @Override public boolean isBadEnv() { return false; }
    @Override public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        ServiceInvocationContract.fixCaller(method.getName(), args, BlackBoxCore.getAppPackageName(),
            BlackBoxCore.getBUid(), BlackBoxCore.getHostPkg(), BlackBoxCore.getHostUid());
        if (args != null) for (Object arg : args) ContextCompat.fixCallerAttribution(arg);
        return ServiceInvocationContract.invoke(getBase(), method, args);
    }
}
