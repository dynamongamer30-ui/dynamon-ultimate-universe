package top.niunaijun.blackbox.core.system.pm;

/** Compatibility is restricted to the two exact pinned upstream replacement-service APKs. */
public final class MicrogTrustPolicy {
    private MicrogTrustPolicy() {}
    public static boolean trusted(String pkg, long version, long size, String sha256) {
        return "com.google.android.gms".equals(pkg) && version == 252432034L && size == 108113833L
            && "e5e6cba078bdec812b5450599350e5c1a12c8b7438da5bf77123af170f8c1a35".equals(sha256)
            || "com.android.vending".equals(pkg) && version == 84022634L && size == 4210169L
            && "9b8616011cc8f026bcbbe094df850794abb9d6d9f23214d7a8f8c4d1033ea012".equals(sha256);
    }
    public static boolean candidate(String pkg) {
        return "com.google.android.gms".equals(pkg) || "com.android.vending".equals(pkg);
    }
}
