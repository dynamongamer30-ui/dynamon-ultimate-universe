package top.niunaijun.blackbox.core.system.accounts;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

/** Discovery depends on installed services, never on an already-created account. */
public final class InstalledAuthenticators {
    private InstalledAuthenticators() {}
    public static <T> List<T> select(Map<String, T> snapshot, Predicate<T> installedForUser) {
        List<T> result = new ArrayList<>();
        for (T service : snapshot.values()) if (installedForUser.test(service)) result.add(service);
        return result;
    }
}
