// Pure policy helpers: no credentials, database access, or request state.
export function licenseReason(activation, keyData, fingerprint, now) {
  if (!activation || !keyData) return 'no-login';
  const key = String(activation.key || activation.Key || '');
  if (!key || String(keyData.device || '') !== fingerprint) return 'device_mismatch';
  if (String(keyData.status || 'active').toLowerCase() !== 'active') return 'suspended';
  let last = Number(activation.lastLogin || 0);
  if (last > 0 && last < 1e12) last *= 1000;
  if (!Number.isFinite(last) || last > now + 60000 || now - last > 1800000 || last <= 0) return 'no-login';
  const expiry = Number(keyData.expiry || 0);
  if (!Number.isFinite(expiry) || expiry < 0) return 'invalid_license';
  if (expiry > 0 && expiry * 1000 <= now) return 'expired';
  return '';
}
export function maintenance(config, locks) {
  return config === true || !!(locks && (locks.app === true || locks.mods === true));
}
