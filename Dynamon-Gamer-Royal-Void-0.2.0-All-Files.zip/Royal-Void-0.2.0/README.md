# Dynamon Gamer · Royal Void 0.2.0

Start with **START_HERE.md**. Java 7 native Android source, no custom XML layouts or application R references, no runtime dependency on the preview MainActivity.

## Changed from 0.1

- Original generated dragon/crown DG logo replaces the anime avatar and geometric launcher symbol.
- Starts with the floating launcher; draggable panel header, compact launcher and existing edge snapping.
- Neutral translucent glass panels plus a downsampled, blurred game snapshot on Android 8+ when PixelCopy succeeds. Blur is refreshed when opening, not continuously; older/unsupported captures use translucent styling.
- Stronger perspective opening animation, card/scroll transitions, themed skin selection markers and a costume symbol instead of the Instagram-like skin tab symbol.
- Action-specific top-centre feedback: successful messages last one second, errors 2.6 seconds. No external automation idle badge. Automation status remains within the menu.
- Set all consumables above the inventory list; quantity updates refresh the visible list. Original item icons load from host APK assets with bounded decoding and fit-centre display.
- Combined supported unlock action and clearer collection labels. Collection records are not playable monsters. Speculative purchase-unlock attempts are not included.
- First turn control removed as requested; original stat-cap/shop flags exposed.
- One Command centre contains feedback, motion, size, opacity, sound volume, launcher controls, and portable one-file export/import. Old separate named switch-only profiles removed.
- New native encrypted-payload loader can replace `loader.js` after the HTML/hook migration in START_HERE. Existing loader remains supported for staged testing.
- Gameplay runtime and cosmetic catalog are no longer embedded in Java's GameScripts; they belong to the authorized game payload. DEX contains the UI and command adapter.
- Community links come from signed payload branding with HTTPS public config fallback for old payloads, rather than a hardcoded social URL array in BrandConfig.
- Gradle release configuration enables ProGuard with stable smali entrypoints. Standalone D8 build is NOT an obfuscating build.

## Files

| Area | Files |
|---|---|
| Main window/pages | ModController.java |
| Floating launcher | FloatingLauncher.java |
| Fonts/colors/glass | FontManager.java, RoyalVoidTheme.java, GlassPanelDrawable.java, GlassBackdropView.java, GlowDrawable.java |
| Motion | MotionEffects.java, NavigationAnimator.java, ScrollMotion.java |
| Feedback | HapticEngine.java, SoundEngine.java |
| Icons/controls | IconView.java, SelectionView.java, ArtworkView.java, ToggleView.java, ProgressRingView.java |
| Item/skin artwork | LocalArtworkLoader.java, SkinPackManager.java |
| Settings/export/import | PreferencesStore.java, PortableProfile.java |
| Game connection | GameBridge.java, GameConnection.java, FeatureRegistry.java, generated GameScripts.java |
| Native payload delivery | NativePayloadLoader.java, PayloadCrypto.java |
| Branding | BrandConfig.java, PublicConfigClient.java, integration/brand.json, new logo asset |
| Entry/lifecycle | ModEntry.java, WebViewFinder.java |
| Preview only | PreviewConnection.java, preview/.../MainActivity.java |
| Server draft | backend/license/ |

All Java files in src are part of the core. Assets go under assets/royal_void in the host APK. tools/tests/integration/backend/docs do not go into the APK. The removable preview is separate. Gradle configuration/manifest are for compiling the preview, not replacing the host manifest.

## Verification and remaining work

Local checks cover Java syntax, the pure Java crypto helper on the desktop JDK, simulated game commands/headless runtime, and mocked Worker authorization paths. No new APK/DEX was compiled here; Android SDK/build tools/device are unavailable. PixelCopy alignment, native loader delivery, document picker, ProGuard output, sound playback, and real gameplay need phone testing.

There is no full 3D rendering engine. Depth is Android view perspective motion. Open Sans remains the licensed bundled font; repository premium-font redistribution was not added without confirmed provenance.

Read SECURITY.md for actual protection limits. The source is being published to the existing PUBLIC branch by explicit user choice. Other people can download and modify it.
