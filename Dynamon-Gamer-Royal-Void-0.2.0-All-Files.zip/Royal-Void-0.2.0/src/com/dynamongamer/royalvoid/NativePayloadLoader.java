package com.dynamongamer.royalvoid;

import android.os.*;
import android.util.Base64;
import android.webkit.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.Arrays;
import java.util.concurrent.*;

/** Opt-in replacement for assets/www/loader.js; never run both loaders together. */
public final class NativePayloadLoader {
    public interface Listener { void status(String message,boolean error); }
    private static final String SERVER="https://dg.dynamongamer30.workers.dev";
    private static final String PUBLIC_KEY="MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEBvmVi6bDPa9eUOBNsYKr+IQ3JW3rQPQpeWxhi/fTTuLIn8jtG3vDb1G2y9286BKW1GKs2zksU9Grw6eFMHF7Aw==";
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final WebView web;
    private final Listener listener;
    private volatile boolean closed;
    private volatile boolean busy,loaded;
    private String fingerprint,build;
    private long started;
    private int generation;
    public NativePayloadLoader(WebView w,Listener l){web=w;listener=l;}
    public void start(){
        if(closed||busy||loaded)return; busy=true;started=System.currentTimeMillis();generation++; waitForDevice(generation);
    }
    private void tell(final String message,final boolean error){ui.post(new Runnable(){public void run(){if(!closed)listener.status(message,error);}});}
    private void fail(String message){busy=false;tell(message,true);}
    private void waitForDevice(final int token){
        if(closed||token!=generation)return;
        if(System.currentTimeMillis()-started>45000){fail("Finish login, then choose Retry game loading in launcher shortcuts");return;}
        web.evaluateJavascript("(function(){return {ready:window.__DG_NATIVE_BOOT_READY===true,loaded:!!window.lime,fp:window.device&&window.device.uuid?String(window.device.uuid):null};})()",new ValueCallback<String>(){public void onReceiveValue(String value){
            if(closed||token!=generation)return;
            try{
                JSONObject result=new JSONObject(value);
                if(result.optBoolean("loaded")){fail("Another loader already loaded the game. Do not enable both loaders.");return;}
                String fp=result.optString("fp","");
                if(result.optBoolean("ready") && !fp.isEmpty() && !fp.equals("null") && fp.length()<=200){fingerprint=fp;tell("Verifying your game access…",false);download(token);return;}
            }catch(Exception ignored){}
            ui.postDelayed(new Runnable(){public void run(){waitForDevice(token);}},500);
        }});
    }
    private JSONObject request(String path,JSONObject body,int limit) throws Exception {
        if(closed)throw new IOException("Loader closed");
        HttpURLConnection connection=(HttpURLConnection)new URL(SERVER+path).openConnection();
        connection.setConnectTimeout(15000);connection.setReadTimeout(20000);connection.setInstanceFollowRedirects(false);
        connection.setRequestProperty("Cache-Control","no-store");
        try{
            if(body!=null){connection.setRequestMethod("POST");connection.setDoOutput(true);connection.setRequestProperty("Content-Type","application/json");
                byte[] bytes=body.toString().getBytes("UTF-8");connection.setFixedLengthStreamingMode(bytes.length);
                OutputStream out=connection.getOutputStream();try{out.write(bytes);}finally{out.close();}}
            if(connection.getResponseCode()!=200)throw new IOException("Server unavailable ("+connection.getResponseCode()+")");
            InputStream in=connection.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int n;
            try{while((n=in.read(buffer))!=-1){if(closed)throw new IOException("Loader closed");if(out.size()+n>limit)throw new IOException("Server response exceeds limit");out.write(buffer,0,n);}}finally{in.close();}
            return new JSONObject(new String(out.toByteArray(),"UTF-8"));
        }finally{connection.disconnect();}
    }
    private void download(final int token){worker.execute(new Runnable(){public void run(){
        byte[] key=null,plaintext=null;
        try{
            JSONObject payload=request("/payload",null,11000000);
            final String id=payload.getString("build");if(!id.matches("[A-Za-z0-9._-]{1,128}"))throw new IOException("Invalid build identifier");
            byte[] ciphertext=Base64.decode(payload.getString("ct_b64"),Base64.DEFAULT);
            if(!PayloadCrypto.verify(Base64.decode(PUBLIC_KEY,Base64.DEFAULT),ciphertext,Base64.decode(payload.getString("sig_b64"),Base64.DEFAULT)))throw new IOException("Payload signature mismatch");
            JSONObject check=new JSONObject();check.put("fp",fingerprint);check.put("build",id);check.put("ctsha",PayloadCrypto.hash(ciphertext));
            JSONObject access=request("/check",check,65536);
            if(access.optBoolean("banned")||access.optBoolean("blocked"))throw new IOException(access.optBoolean("blocked")?"Please finish login, then retry game loading":"Game access denied");
            if(!access.has("key"))throw new IOException("Server did not release the payload key");
            key=Base64.decode(access.getString("key"),Base64.DEFAULT);
            plaintext=PayloadCrypto.decrypt(key,Base64.decode(payload.getString("iv_b64"),Base64.DEFAULT),ciphertext);
            final String code=new String(plaintext,"UTF-8");
            ui.post(new Runnable(){public void run(){if(closed||token!=generation)return;build=id;inject(code,0,token);}});
        }catch(Exception e){fail(e.getMessage()==null?"Unable to load the game":e.getMessage());}
        finally{if(key!=null)Arrays.fill(key,(byte)0);if(plaintext!=null)Arrays.fill(plaintext,(byte)0);}
    }});}
    private void inject(final String code,final int offset,final int token){
        if(closed||token!=generation)return;
        if(offset==0){web.evaluateJavascript("window.__DG_NATIVE_SOURCE=[];true",new ValueCallback<String>(){public void onReceiveValue(String v){append(code,0,token);}});return;}
        append(code,offset,token);
    }
    private void append(final String code,final int offset,final int token){
        if(closed||token!=generation)return;
        if(offset>=code.length()){boot(token);return;}
        final int end=Math.min(code.length(),offset+24000);
        web.evaluateJavascript("window.__DG_NATIVE_SOURCE.push("+JSONObject.quote(code.substring(offset,end))+");true",new ValueCallback<String>(){public void onReceiveValue(String value){
            if(!"true".equals(value)){fail("Game page changed during loading; restart the app");return;}append(code,end,token);
        }});
    }
    private void boot(final int token){
        if(closed||token!=generation)return;
        web.evaluateJavascript("(function(){try{window.__DG_SERVER="+JSONObject.quote(SERVER)+";var code=window.__DG_NATIVE_SOURCE.join('');delete window.__DG_NATIVE_SOURCE;(0,eval)(code);if(!window.lime)throw Error('Missing game engine');var s=window.getSize();window.lime.embed('dynamons_world','content',s.width*2,s.height*2,{background:'000000'});return {ok:true};}catch(e){return {ok:false,error:String(e.message||e)};}})()",new ValueCallback<String>(){public void onReceiveValue(String value){
            if(closed||token!=generation)return;
            try{JSONObject r=new JSONObject(value);if(!r.optBoolean("ok"))throw new IOException(r.optString("error","Game boot failed"));
                busy=false;loaded=true;tell("Game loaded · open the floating menu",false);ui.postDelayed(heartbeat,600000);
            }catch(Exception e){fail(e.getMessage()==null?"Game boot failed":e.getMessage());}
        }});
    }
    private final Runnable heartbeat=new Runnable(){public void run(){
        if(closed||!loaded)return;
        worker.execute(new Runnable(){public void run(){try{
            JSONObject body=new JSONObject();body.put("fp",fingerprint);body.put("build",build);
            JSONObject response=request("/heartbeat",body,65536);
            if(response.optBoolean("banned")||response.optBoolean("blocked")){
                ui.post(new Runnable(){public void run(){if(closed)return;loaded=false;busy=false;
                    web.evaluateJavascript("(function(){if(window.__DG_NATIVE)window.__DG_NATIVE.command('stopAll',{});document.body.textContent='Dynamon Gamer: game access revoked. Restart and sign in.';})()",null);
                    tell("Game access revoked",true);
                }});return;
            }
        }catch(Exception e){tell("Connection lost · access will be checked again",true);}
        if(!closed)ui.postDelayed(heartbeat,600000);
        }});
    }};
    public void close(){closed=true;generation++;ui.removeCallbacksAndMessages(null);worker.shutdownNow();}
}
