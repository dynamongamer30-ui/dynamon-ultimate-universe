# Injection

Follow START_HERE.md for exact placement in the supplied MainActivity and the two loader choices.

Existing loader: `ModEntry.attach(Activity, WebView)`.
Native loader replacing loader.js: `ModEntry.attachWithLoader(Activity, WebView)`.
One-WebView discovery: `ModEntry.attach(Activity)` remains available for existing loader integration only.

Attach after WebView initialization, on the UI thread. The supplied game stores its WebView in MainActivity.z. p1 contains that WebView immediately after its assignment; insert the explicit hook there. The core requires no preview MainActivity, custom layout resource, overlay service, or JavaScript interface changes.

Build/inject all core Java classes and assets/royal_void. Do not overwrite the host's original DEX files or add duplicate core classes. The runtime needs API 19+, compile SDK 28+ recommended. For standalone DEX building, set ANDROID_JAR to a platform jar and run tools/build_dex.sh with a JDK/jar/D8 installed. The preview Activity is excluded by this script. This D8 path does not obfuscate implementation classes.

AIDE release builds can use the supplied ProGuard configuration. It keeps ModEntry smali hook names stable. Never publish your private signing key, upload bundles containing AES keys, or obfuscation mapping file. The target APK must be rebuilt and signed using the normal phone workflow.
