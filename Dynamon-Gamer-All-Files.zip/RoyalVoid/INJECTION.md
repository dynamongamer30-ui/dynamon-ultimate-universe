# Native integration

The runtime needs an Activity and the **actual game WebView**. It adds views to that Activity's decor; no overlay-service permission or additional Activity is needed in the target APK.

## Java entry point

After the game's WebView has been created, on the Android UI thread:

```java
com.dynamongamer.royalvoid.ModEntry.attach(this, gameWebView);
```

If the Activity contains exactly one WebView, this convenience entry point searches for up to 30 seconds:

```java
com.dynamongamer.royalvoid.ModEntry.attach(this);
```

When there are multiple WebViews (for example login, ads and game), use the explicit overload. The automatic finder deliberately does not guess between them.

The component is idempotent per Activity. It registers lifecycle callbacks to clean up when that Activity is destroyed. An optional explicit cleanup call is:

```java
com.dynamongamer.royalvoid.ModEntry.detach(this);
```

The bridge does not change the host WebView's client, URLs, file-access options, JavaScript settings, or native JavaScript interfaces. The game must already have JavaScript enabled and its patched class registry exposed as `$DW` or `$hxClasses`.

## Smali example

In the host Activity's `onCreate` **after the WebView setup**, if `p0` is that Activity:

```smali
invoke-static {p0}, Lcom/dynamongamer/royalvoid/ModEntry;->attach(Landroid/app/Activity;)V
```

Prefer the explicit version when the WebView is already in a register, for example `v1`:

```smali
invoke-static {p0, v1}, Lcom/dynamongamer/royalvoid/ModEntry;->attach(Landroid/app/Activity;Landroid/webkit/WebView;)V
```

These are examples, not offsets or register numbers verified against your APK. The target Activity/smali was not provided. Confirm register types and method position in your APK editor before injection. Some Cordova versions expose an engine wrapper rather than an Android WebView; pass the wrapper's underlying View only if it is a WebView.

## Files to copy

1. Build the core using `tools/build_dex.sh`, or compile the core Java package in your existing phone build project.
2. Add the resulting DEX files under unused names such as `classes9.dex` only if that number is actually free. Preserve the host's existing DEX files.
3. Copy the `royal_void/` asset folder into the target APK's `assets/` directory, so font paths resolve as `assets/royal_void/fonts/ui_regular.ttf`.
4. Preserve `.wav` files uncompressed if your APK editor supports it, so `AssetManager.openFd` can read them. Gradle preview builds set `noCompress 'wav'`.
5. Add the attachment call. The runtime needs Android 4.4/API 19 or later. The host normally already has INTERNET permission for its game loader and skin storage.
6. Rebuild and sign with your normal APK workflow. Re-signing may affect services that validate the host certificate; this project cannot verify those APK-specific integrations.

The removable preview class is `com.dynamongamer.preview.MainActivity`; nothing in `com.dynamongamer.royalvoid` depends on it. Excluding `preview/` from the DEX build is preferable to deleting a class after compilation.

## Recommended payload sequence

1. Build/run the preview and test the DEX attachment with the current game.
2. Build the new `dist/dynamons_world_native.js` through your existing encryption/signing pipeline using the same signing key and Worker URL.
3. Test the updated native APK and payload together before making that payload active for other users. A headless payload has no legacy DOM menu for users who have not received the native DEX.
4. Keep your previous payload available for rollback in your existing deployment process.

## Phone acceptance checks

- Preview clearly says PREVIEW and sample actions never change an account.
- Font loads; all text remains readable at your phone's larger font setting.
- Launcher drags, snaps, survives rotation, opens with one tap and shows quick actions on hold.
- Compact edge handle restores the menu; Back closes the panel.
- Sidebar, scroll, keyboard and dialog input work in portrait and landscape.
- Feedback settings respect silent mode and system haptics.
- A currency change shows the game-confirmed result; a failed/locked action shows a reason.
- Reopening pages does not re-enable remotely locked features.
- Starting/stopping automation restores its dependent controls; pause/resume works on the updated payload.
- Leaving/recreating the Activity does not duplicate menus or polling.
- Your loader's login, signature verification and heartbeat still run normally.

No Android device/emulator acceptance checks were possible in the build environment.
