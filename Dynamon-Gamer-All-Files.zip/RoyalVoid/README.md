# Dynamon Gamer · Royal Void

Java 7 native Android menu **source preview, version 0.1.0**. The runtime component uses programmatic Android Views and no application resource IDs, XML layouts, AndroidX, or native libraries. The included assets supply fonts, branding, and sounds.

## Start here on your phone

1. Extract this folder to a writable location, such as `Download/RoyalVoid`.
2. Open the folder as a project in AIDE. The included Gradle configuration targets Android SDK 28 and Java 7. If your AIDE version creates projects using a different Android Gradle Plugin version, create a basic Java Activity project with AIDE and use that generated build configuration, preserving the source directories listed below.
3. The core Java package is in `src/com/dynamongamer/royalvoid/`. The removable preview Activity is in `preview/com/dynamongamer/preview/`. Copy both into AIDE's Java source directory if its project format does not support the supplied `sourceSets`.
4. Copy `assets/royal_void/` into the project's assets directory. For a modern Gradle layout this is `app/src/main/assets/royal_void/`.
5. Use the supplied `AndroidManifest.xml` for the preview, or copy its Activity declaration and INTERNET permission into the generated preview manifest. Its theme references Android's built-in resource; there are no custom resources to copy.
6. Build and run **Royal Void Preview**. It uses explicitly labeled sample data. No game account is connected. Skin manifest/image reads use the existing public storage when you tap Load; preview commands do not change game data.

There is no Gradle wrapper included. AIDE must provide Gradle/Android build tools, or they must already be installed. The old plugin version is a compatibility starting point, not a claim that every AIDE release supports it.

## Included

- Royal Void dark glass-style panels, violet gradients, rounded borders, ambient glow and Open Sans typography.
- Drawn symbols, supplied brand logo and a new geometric launcher emblem.
- Panel opening/closing, restrained perspective motion, navigation transitions, animated toggles, scroll reveals and progress rings.
- Draggable edge-snapping launcher; long-press shortcuts; compact restore handle. The handle stays visible so the menu remains recoverable.
- Responsive panel placement, adjustable menu height, saved launcher position and per-page scroll positions.
- Search, favorites, named feature profiles, optional pinned automation status, reduced motion, sounds and haptics.
- Home/currency, battle, arena, items, unlocks, team, skins, advanced controls, settings and community pages.
- WebView bridge with JSON serialization, timeouts, duplicate-command suppression and activity cleanup.
- Headless adaptation of the supplied JavaScript hooks, with automation pause/resume, lock enforcement and control restoration.
- Your five social/website links in `BrandConfig.java`.
- Public Supabase skin manifests and bounded thumbnail decoding with aspect-preserving native display.

## Build status — read before injecting

**No APK or DEX binary has been produced here.** Android SDK/D8 were unavailable and the configured network proxy could not download the SDK dependency. The full Android application has therefore not been compiled or rendered on-device.

Completed local checks:

- All core and preview Java files parse with the JDK compiler parser. No lambda or method-reference syntax is used. This is a syntax check, not Android API type checking or proof of AIDE compatibility.
- `GameScripts.java` compiles independently with the available JDK, checking generated string/constant limits.
- 24 command-bridge behavior tests pass in Node.
- The complete headless runtime passes installation, snapshot, no-legacy-menu, idempotence, pause/resume and stop/restoration checks in a simulated browser/game context.
- All 34 original rules match the supplied `1.js`, without overlaps. The resulting native-ready game payload passes JavaScript syntax checking.

Device testing is still required for Android compilation, rendering, font size, touch behavior, timing, memory usage, skin network access, WebView attachment, and actual game actions. Desktop simulated tests do not verify real gameplay or remote account acceptance.

## Two integration choices

**Recommended: native-ready OTA payload plus DEX.** The `dist/dynamons_world_native.js` file contains the supplied game with all 34 rules, followed by the headless menu engine and native command adapter. It does not mount the old DOM menu. Build and inject the native menu before deploying this payload, otherwise there will be no visible menu.

This payload is **unsigned and unencrypted**. Run your existing `build_loader.py` on it using your **existing signing_key.pem** and existing server URL. Generating a new signing key would require replacing the public key baked into your loader. Your private signing key was not supplied and is not included. No Cloudflare upload or Supabase/GitHub write was performed.

**Existing payload:** the DEX can attach to your current modded game. It reuses the existing `__DG_API`, hides the legacy DOM menu and adds the native adapter. Most controls work through existing hooks. Pause/resume requires the updated headless payload; older payloads return an explicit unsupported message.

## Injecting into the host APK

See `INJECTION.md` for the Java entry point and a smali example. The runtime package never references `MainActivity` or generated `R` classes. The minimum Android API is **19** because the bridge uses `WebView.evaluateJavascript`.

For an SDK/Termux workflow, `tools/build_dex.sh` compiles **only `src/`**, excluding the preview Activity:

```sh
export ANDROID_JAR=/your/android-sdk/platforms/android-28/android.jar
bash tools/build_dex.sh
```

A JDK, `jar`, and Android `d8` must already be installed and on PATH. Android D8 is not bundled. JDKs that no longer accept source 7 can use `DG_SOURCE_LEVEL=8`; the project still contains Java 7 syntax. Prefer your AIDE Java 7 compiler for verifying the intended phone toolchain.

The resulting DEX is under `dist/dex/` only after a successful local build. Copy every generated DEX if D8 emits more than one, using unused sequential names in the target APK.

## Runtime expectations and limits

- The game still runs in its existing WebView. Java owns the interface; JavaScript owns game hooks. This is not a port of the game engine to Java.
- A tiny host Activity/WebView attachment call is required. Automatic discovery only attaches when exactly one WebView is present; otherwise pass the correct WebView explicitly.
- Existing login, signed payload loading and access checks stay in the host loader. No upload bundle keys or backend credentials are embedded in this project.
- Glass styling uses translucent layered drawing. Real background blur, particles and a separate 3D rendering engine are not included.
- New native Java UI changes require rebuilding/reinjecting the DEX. The headless game payload can still use your OTA build pipeline.
- Settings and favorite profiles are local. Cloud synchronization is not included.
- The launcher can collapse to a visible edge handle. There is no invisible global gesture listener.
- The native artwork view prevents stretching **inside this menu**. The oversized game-skin images in the earlier screenshot are not repaired by this build; matching their original canvas dimensions/anchors still requires inspecting the source skin assets.
- Unlock actions use available game records. DynaDex unlocks do not promise a playable copy of every monster. Speculative IAP unlock attempts from the old menu are omitted. Shop/wheel fixes remain in the original patch rules.
- World and arena automation cannot run together. Locks can stop automation. Detaching the native bridge stops automation. Background operation depends on the host game's WebView lifecycle.
- Search currently covers feature switches; inventory has its own filter. The first 60 matching items/skins are rendered to bound view count. Skin Apply to all includes the complete loaded manifest.

## Files to edit

| Area | Source |
|---|---|
| Name, version, links | `BrandConfig.java` |
| Palette and base text | `RoyalVoidTheme.java`, `FontManager.java` |
| Glass/glow | `GlassPanelDrawable.java`, `GlowDrawable.java` |
| Icons and artwork | `IconView.java`, `ArtworkView.java` |
| Motion | `MotionEffects.java`, `NavigationAnimator.java`, `ScrollMotion.java` |
| Feedback | `HapticEngine.java`, `SoundEngine.java` |
| Controls/status | `ToggleView.java`, `ProgressRingView.java`, `PinnedStatusView.java` |
| Panel/pages | `ModController.java` |
| Floating launcher | `FloatingLauncher.java` |
| Settings/profiles | `PreferencesStore.java`, `ProfileStore.java` |
| Features and commands | `FeatureRegistry.java`, `GameBridge.java`, `GameConnection.java` |
| Entry/lifecycle | `ModEntry.java`, `WebViewFinder.java` |
| Skin downloads | `SkinPackManager.java` |
| Generated game hooks | `GameScripts.java` |
| Sample data | `PreviewConnection.java` |
| Removable preview | `preview/.../MainActivity.java` |

## Rebuilding the game payload

After editing `tests/headless_runtime.js` or `tests/native_adapter.js`, regenerate the embedded Java script:

```sh
python tools/embed_runtime.py
python tools/prepare_payload.py --original /path/to/1.js
bash tools/check.sh
```

`prepare_payload.py` refuses to overwrite the original and refuses to emit a new payload if any rule fails or edit spans overlap. It does not invoke the original patcher's permissive apply command.

The `integration/` folder contains your supplied patch engine and manifest for reproducibility. The `tests/` JavaScript files are development sources; app execution uses their generated Java strings, so they do not have to be copied into APK assets.

## Branding links

- https://youtube.com/@dynamongamer07
- https://whatsapp.com/channel/0029VbBdAcZ05MUmgk8cQP05
- https://www.instagram.com/stoicist_zayen
- https://t.me/dynamonsworld07
- https://dynamongamer.space/

The embedded logo is the unchanged 150×150 image extracted from your supplied menu. Fonts and sound provenance are in `assets/royal_void/licenses/`.
