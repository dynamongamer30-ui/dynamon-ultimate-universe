#!/usr/bin/env bash
set -euo pipefail
DG_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
node --check "$DG_ROOT/tests/bootstrap.js"
node "$DG_ROOT/tests/bridge.test.js"
node "$DG_ROOT/tests/runtime.test.js"
# JDK 17+ is only required for this development syntax-check utility.
# The Android app itself uses Java 7 syntax.
java "$DG_ROOT/tools/ParseJava.java" "$DG_ROOT/src"
java "$DG_ROOT/tools/ParseJava.java" "$DG_ROOT/preview"
