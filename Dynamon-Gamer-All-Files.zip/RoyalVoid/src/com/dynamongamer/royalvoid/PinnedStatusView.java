package com.dynamongamer.royalvoid;

import android.content.Context;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;

public final class PinnedStatusView extends LinearLayout {
    private final TextView title;
    private final TextView detail;
    
    public PinnedStatusView(Context c) {
        super(c);
        setOrientation(VERTICAL);
        setGravity(Gravity.CENTER_VERTICAL);
        int p = RoyalVoidTheme.dp(c, 12);
        setPadding(p, p, p, p);
        setBackground(new GlassPanelDrawable(RoyalVoidTheme.dp(c, 16), true));
        title = RoyalVoidTheme.text(c, "ROYAL VOID", 10, RoyalVoidTheme.LAVENDER, true);
        detail = RoyalVoidTheme.text(c, "Automation idle", 12, RoyalVoidTheme.TEXT, true);
        addView(title);
        addView(detail);
        setClickable(true);
        setFocusable(true);
        setContentDescription("Automation status. Tap to open menu.");
    }
    
    public void state(JSONObject s) {
        JSONObject w = s.optJSONObject("world");
        JSONObject g = s.optJSONObject("grind");
        if (w != null && w.optBoolean("on")) detail.setText((w.optBoolean("paused") ? "Paused \u00b7 " : "World \u00b7 ") + Math.round(w.optDouble("pct", 0)) + "%"); else if (g != null && g.optBoolean("on")) detail.setText(g.optBoolean("paused") ? "Arena paused" : "Arena running"); else detail.setText(s.optBoolean("ready") ? "Automation idle" : "Waiting for game");
    }
}
