package com.dynamongamer.royalvoid;

import android.graphics.*;
import android.graphics.drawable.Drawable;

public final class GlassPanelDrawable extends Drawable {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float radius;
    private final boolean strong;
    private int alpha = 255;
    
    public GlassPanelDrawable(float radius, boolean strong) {
        this.radius = radius;
        this.strong = strong;
    }
    
    public void draw(Canvas c) {
        RectF r = new RectF(getBounds());
        r.inset(1, 1);
        p.setShader(new LinearGradient(r.left, r.top, r.right, r.bottom, strong ? new int[]{-182775763, -99940588} : new int[]{-299624398, -267252452}, null, Shader.TileMode.CLAMP));
        p.setAlpha(alpha);
        p.setStyle(Paint.Style.FILL);
        c.drawRoundRect(r, radius, radius, p);
        p.setShader(null);
        p.setColor(-12308141);
        p.setAlpha(alpha);
        p.setStrokeWidth(1);
        p.setStyle(Paint.Style.STROKE);
        c.drawRoundRect(r, radius, radius, p);
        p.setStyle(Paint.Style.FILL);
    }
    
    public void setAlpha(int a) {
        alpha = a;
        invalidateSelf();
    }
    
    public void setColorFilter(ColorFilter f) {
        p.setColorFilter(f);
    }
    
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
