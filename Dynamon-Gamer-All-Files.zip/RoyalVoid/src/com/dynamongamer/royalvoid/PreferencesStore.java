package com.dynamongamer.royalvoid;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;

public final class PreferencesStore {
    private final SharedPreferences p;
    
    public PreferencesStore(Context c) {
        p = c.getSharedPreferences("dg_royal_void_v1", Context.MODE_PRIVATE);
    }
    
    public boolean bool(String key, boolean fallback) {
        return p.getBoolean(key, fallback);
    }
    
    public int integer(String key, int fallback) {
        return p.getInt(key, fallback);
    }
    
    public float number(String key, float fallback) {
        return p.getFloat(key, fallback);
    }
    
    public String string(String key, String fallback) {
        return p.getString(key, fallback);
    }
    
    public void set(String key, boolean value) {
        p.edit().putBoolean(key, value).apply();
    }
    
    public void set(String key, int value) {
        p.edit().putInt(key, value).apply();
    }
    
    public void set(String key, float value) {
        p.edit().putFloat(key, value).apply();
    }
    
    public void set(String key, String value) {
        p.edit().putString(key, value).apply();
    }
    
    public boolean favorite(String key) {
        return bool("fav." + key, false);
    }
    
    public boolean flipFavorite(String key) {
        boolean v = !favorite(key);
        set("fav." + key, v);
        return v;
    }
}
