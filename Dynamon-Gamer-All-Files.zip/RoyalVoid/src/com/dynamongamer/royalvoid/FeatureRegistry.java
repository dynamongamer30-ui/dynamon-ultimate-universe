package com.dynamongamer.royalvoid;

public final class FeatureRegistry {
    
    private FeatureRegistry() {
    }
    
    public static final class Feature {
        public final String key;
        public final String title;
        public final String description;
        public final String category;
        public final String icon;
        
        Feature(String k, String t, String d, String c, String i) {
            key = k;
            title = t;
            description = d;
            category = c;
            icon = i;
        }
    }
    public static final Feature[] ALL = {new Feature("god", "God mode", "Protect your active team from damage", "Battle", "shield"), new Feature("oneHit", "One-hit damage", "Defeat the active enemy quickly", "Battle", "bolt"), new Feature("crit", "Critical hits", "Force impressive ability hits", "Battle", "star"), new Feature("statusImmune", "Status immunity", "Protect against sickness and hypnosis", "Battle", "shield"), new Feature("noCD", "No cooldowns", "Keep ability cards ready", "Battle", "bolt"), new Feature("alwaysCatch", "Always catch", "Force the catch-success argument", "Battle", "star"), new Feature("botMatch", "Bot matchmaking", "Route new arena matches to bots", "Arena", "team"), new Feature("winToss", "First turn", "Request first turn in arena battles", "Arena", "bolt"), new Feature("winTrophy", "Win state", "Apply the existing winning-state hook", "Arena", "star"), new Feature("noTrophyLoss", "No trophy loss", "Apply the existing arena win-state hook", "Arena", "shield"), new Feature("fullheal", "Full-heal potions", "Restore full health with a potion", "Advanced", "shield"), new Feature("pvpcd", "Faster arena items", "Use the patched PvP item cooldown", "Advanced", "bolt"), new Feature("itemtimer", "No item wait", "Skip patched item-use timers", "Advanced", "bolt"), new Feature("turnreset", "Refill items each turn", "Reset the per-turn item counter", "Advanced", "items"), new Feature("items5", "Five items per turn", "Raise the patched item-use limit", "Advanced", "items"), new Feature("nicklen", "Longer nicknames", "Use the patched nickname length", "Advanced", "settings"), new Feature("nickval", "Name validation", "Use the patched name-length validation", "Advanced", "settings"), new Feature("maxdef", "Defense cap override", "Use the patched defense ceiling", "Advanced", "shield")};
}
