package com.dynamongamer.royalvoid;

import android.content.Context;
import android.graphics.Typeface;
import java.util.HashMap;

public final class FontManager {
    private static final HashMap<String, Typeface> CACHE = new HashMap<String, Typeface>();
    
    private FontManager() {
    }
    
    public static synchronized Typeface get(Context c, String weight) {
        Typeface t = CACHE.get(weight);
        if (t != null) return t;
        try {
            t = Typeface.createFromAsset(c.getAssets(), "royal_void/fonts/ui_" + weight + ".ttf");
        } catch (Exception e) {
            t = Typeface.create("sans-serif", "bold".equals(weight) ? Typeface.BOLD : Typeface.NORMAL);
        }
        CACHE.put(weight, t);
        return t;
    }
}
