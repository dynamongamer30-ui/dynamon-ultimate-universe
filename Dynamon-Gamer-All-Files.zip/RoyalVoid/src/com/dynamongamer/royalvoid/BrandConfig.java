package com.dynamongamer.royalvoid;

public final class BrandConfig {
    
    private BrandConfig() {
    }
    public static final String NAME = "Dynamon Gamer";
    public static final String EDITION = "Royal Void";
    public static final String VERSION = "0.1.0";
    public static final String[][] LINKS = {{"YouTube", "https://youtube.com/@dynamongamer07", "play"}, {"WhatsApp", "https://whatsapp.com/channel/0029VbBdAcZ05MUmgk8cQP05", "chat"}, {"Instagram", "https://www.instagram.com/stoicist_zayen", "camera"}, {"Telegram", "https://t.me/dynamonsworld07", "send"}, {"Website", "https://dynamongamer.space/", "globe"}};
}
