package com.dynamongamer.royalvoid;

import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public final class ProfileStore {
    private final PreferencesStore prefs;
    
    public ProfileStore(PreferencesStore p) {
        prefs = p;
    }
    
    private JSONObject all() {
        try {
            return new JSONObject(prefs.string("namedProfiles", "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }
    
    public ArrayList<String> names() {
        JSONObject o = all();
        ArrayList<String> list = new ArrayList<String>();
        Iterator<String> i = o.keys();
        while (i.hasNext()) list.add(i.next());
        Collections.sort(list);
        return list;
    }
    
    public JSONObject read(String name) {
        JSONObject o = all().optJSONObject(name);
        return o == null ? new JSONObject() : o;
    }
    
    public void save(String name, JSONObject flags) throws Exception {
        name = name.trim();
        if (name.length() < 1 || name.length() > 32) throw new Exception("Use a name with 1\u201332 characters");
        JSONObject all = all();
        if (!all.has(name) && all.length() >= 16) throw new Exception("Limit reached: 16 profiles");
        JSONObject clean = new JSONObject();
        Iterator<String> keys = flags.keys();
        while (keys.hasNext()) {
            String k = keys.next();
            if (!k.equals("autoWorld") && !k.equals("autoGrind") && !k.equals("saveSettings")) clean.put(k, flags.optBoolean(k));
        }
        all.put(name, clean);
        prefs.set("namedProfiles", all.toString());
    }
    
    public void delete(String name) {
        JSONObject o = all();
        o.remove(name);
        prefs.set("namedProfiles", o.toString());
    }
}
