package com.dynamongamer.royalvoid;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;

public final class ModController {
    final Activity activity;
    final GameConnection game;
    final PreferencesStore prefs;
    final MotionEffects motion;
    final HapticEngine haptics;
    final SoundEngine sounds;
    final SkinPackManager skins = new SkinPackManager();
    final Handler handler = new Handler(Looper.getMainLooper());
    final FrameLayout root;
    private View ambient;
    private ScrollMotion scrollMotion;
    private PinnedStatusView pinned;
    FloatingLauncher launcher;
    LinearLayout panel;
    LinearLayout body;
    LinearLayout nav;
    ScrollView scroll;
    TextView connection;
    TextView notice;
    JSONObject state = new JSONObject();
    boolean visible;
    boolean closed;
    boolean paused;
    boolean requesting;
    String page = "Home";
    String query = "";
    private final HashMap<String, ToggleView> switches = new HashMap<String, ToggleView>();
    private final HashSet<String> inFlight = new HashSet<String>();
    private final ArrayList<TextView> statLabels = new ArrayList<TextView>();
    private final ArrayList<Dialog> dialogs = new ArrayList<Dialog>();
    private ProgressRingView ring;
    private TextView worldLabel;
    private TextView worldStats;
    private TextView pauseButton;
    private TextView grindLabel;
    private boolean automationWorld;
    private boolean expandedNav;
    private final Runnable poll = new Runnable(){
        
        public void run() {
            refresh();
        }
    };
    private final View.OnLayoutChangeListener layoutListener = new View.OnLayoutChangeListener(){
        
        public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
            if (r - l != or - ol || b - t != ob - ot) {
                sizePanel();
                launcher.restore();
            }
        }
    };
    
    public ModController(Activity a, GameConnection g) {
        activity = a;
        game = g;
        prefs = new PreferencesStore(a);
        motion = new MotionEffects(prefs);
        haptics = new HapticEngine(prefs);
        sounds = new SoundEngine(a, prefs);
        sounds.prepare();
        root = new FrameLayout(a);
        root.setClipChildren(false);
        root.setClipToPadding(false);
        root.setFitsSystemWindows(true);
    }
    
    int dp(float n) {
        return RoyalVoidTheme.dp(activity, n);
    }
    
    public void start() {
        ViewGroup host = (ViewGroup)activity.getWindow().getDecorView();
        host.addView(root, new ViewGroup.LayoutParams(-1, -1));
        root.addOnLayoutChangeListener(layoutListener);
        launcher = new FloatingLauncher(activity, prefs, haptics, new FloatingLauncher.Listener(){
            
            public void open() {
                show();
            }
            
            public void quickActions() {
                quick();
            }
        });
        root.addView(launcher, new FrameLayout.LayoutParams(dp(56), dp(56)));
        launcher.compact(prefs.bool("compactLauncher", false));
        launcher.restore();
        pinned = new PinnedStatusView(activity);
        FrameLayout.LayoutParams pinParams = new FrameLayout.LayoutParams(dp(166), dp(66), Gravity.BOTTOM | Gravity.RIGHT);
        pinParams.rightMargin = dp(12);
        pinParams.bottomMargin = dp(70);
        root.addView(pinned, pinParams);
        pinned.setVisibility(prefs.bool("pinStatus", false) ? View.VISIBLE : View.GONE);
        pinned.setOnClickListener(new View.OnClickListener(){
            
            public void onClick(View v) {
                show();
            }
        });
        page = prefs.string("page", "Home");
        if (!Arrays.asList("Home", "Battle", "Arena", "Items", "Unlock", "Team", "Skins", "Advanced", "Settings", "Community").contains(page)) page = "Home";
        buildPanel();
        refresh();
    }
    
    private void buildPanel() {
        panel = new LinearLayout(activity);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(16), dp(14), dp(12));
        panel.setBackground(new GlassPanelDrawable(dp(26), true));
        panel.setVisibility(View.GONE);
        panel.setFocusableInTouchMode(true);
        panel.setOnKeyListener(new View.OnKeyListener(){
            
            public boolean onKey(View v, int key, android.view.KeyEvent e) {
                if (key == android.view.KeyEvent.KEYCODE_BACK && visible) {
                    if (e.getAction() == android.view.KeyEvent.ACTION_UP) hide();
                    return true;
                }
                return false;
            }
        });
        ambient = new View(activity);
        ambient.setBackground(new GlowDrawable());
        ambient.setVisibility(View.GONE);
        ambient.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        root.addView(ambient, new FrameLayout.LayoutParams(dp(360), dp(360), Gravity.TOP | Gravity.CENTER_HORIZONTAL));
        root.addView(panel, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        LinearLayout head = row();
        head.setGravity(Gravity.CENTER_VERTICAL);
        ArtworkView logo = new ArtworkView(activity);
        logo.asset("royal_void/images/brand_logo.jpg");
        head.addView(logo, new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout titles = column();
        titles.setPadding(dp(10), 0, 0, 0);
        titles.addView(text("DYNAMON GAMER", 17, RoyalVoidTheme.TEXT, true));
        titles.addView(text("ROYAL VOID  /  " + BrandConfig.VERSION, 10, RoyalVoidTheme.LAVENDER, true));
        head.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        head.addView(iconButton("close", "Close menu", new Runnable(){
            
            public void run() {
                hide();
            }
        }));
        panel.addView(head);
        connection = text("Connecting to game\u2026", 11, RoyalVoidTheme.MUTED, false);
        connection.setPadding(dp(2), dp(10), 0, dp(10));
        panel.addView(connection);
        LinearLayout main = row();
        panel.addView(main, new LinearLayout.LayoutParams(-1, 0, 1));
        ScrollView navScroll = new ScrollView(activity);
        navScroll.setFillViewport(false);
        navScroll.setVerticalScrollBarEnabled(false);
        nav = column();
        navScroll.addView(nav);
        main.addView(navScroll, new LinearLayout.LayoutParams(dp(52), -1));
        LinearLayout right = column();
        right.setPadding(dp(10), 0, 0, 0);
        main.addView(right, new LinearLayout.LayoutParams(0, -1, 1));
        final EditText search = input("Search features", false);
        search.setSingleLine(true);
        search.setTextSize(13);
        right.addView(search, new LinearLayout.LayoutParams(-1, dp(46)));
        search.addTextChangedListener(new TextWatcher(){
            
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {
            }
            
            public void onTextChanged(CharSequence s, int st, int before, int count) {
                query = s.toString().trim().toLowerCase(java.util.Locale.US);
                render();
            }
            
            public void afterTextChanged(Editable e) {
            }
        });
        scroll = new ScrollView(activity);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setPadding(0, dp(12), 0, dp(12));
        scroll.setVerticalScrollBarEnabled(false);
        body = column();
        scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
        right.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        scrollMotion = new ScrollMotion(scroll, body, motion);
        TextView footer = text("Dynamon Gamer  \u00b7  " + (game.preview() ? "DESIGN PREVIEW" : "LIVE CONTROLS"), 10, RoyalVoidTheme.MUTED, false);
        footer.setPadding(dp(6), dp(10), 0, 0);
        panel.addView(footer);
        makeNav();
        render();
        sizePanel();
    }
    
    private void sizePanel() {
        if (panel == null || root.getWidth() == 0) return;
        int w = root.getWidth();
        int h = root.getHeight();
        boolean land = w > h;
        int width = Math.min(w - dp(16), dp(land ? 620 : 500));
        float fraction = prefs.number("panelHeight", 0.9F);
        FrameLayout.LayoutParams p = (FrameLayout.LayoutParams)panel.getLayoutParams();
        p.width = Math.max(dp(260), width);
        p.height = Math.max(dp(200), Math.min(h - dp(16), (int)(h * fraction)));
        p.gravity = land ? Gravity.RIGHT | Gravity.CENTER_VERTICAL : Gravity.CENTER;
        p.rightMargin = land ? dp(8) : 0;
        panel.setLayoutParams(p);
        View navParent = (View)nav.getParent();
        ViewGroup.LayoutParams np = navParent.getLayoutParams();
        np.width = dp(expandedNav && width > dp(440) ? 135 : 52);
        navParent.setLayoutParams(np);
        panel.setAlpha(prefs.number("opacity", 1));
    }
    
    private void makeNav() {
        nav.removeAllViews();
        String[][] pages = {{"Home", "home"}, {"Battle", "shield"}, {"Arena", "star"}, {"Items", "items"}, {"Unlock", "unlock"}, {"Team", "team"}, {"Skins", "skins"}, {"Advanced", "bolt"}, {"Settings", "settings"}, {"Community", "globe"}};
        nav.addView(iconButton("menu", "Expand navigation", new Runnable(){
            
            public void run() {
                expandedNav = !expandedNav;
                sizePanel();
                makeNav();
            }
        }));
        for (final String[] p : pages) {
            LinearLayout n = row();
            n.setGravity(Gravity.CENTER_VERTICAL);
            n.setPadding(dp(12), 0, dp(8), 0);
            n.setMinimumHeight(dp(48));
            n.setContentDescription(p[0]);
            n.setFocusable(true);
            n.setBackground(RoyalVoidTheme.shape(page.equals(p[0]) ? RoyalVoidTheme.DEEP : Color.TRANSPARENT, page.equals(p[0]) ? RoyalVoidTheme.PURPLE : 0, dp(14)));
            n.addView(new IconView(activity, p[1], page.equals(p[0]) ? RoyalVoidTheme.LAVENDER : RoyalVoidTheme.MUTED), new LinearLayout.LayoutParams(dp(24), dp(24)));
            if (expandedNav) {
                TextView label = text(p[0], 12, RoyalVoidTheme.TEXT, true);
                label.setPadding(dp(10), 0, 0, 0);
                n.addView(label);
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48));
            lp.bottomMargin = dp(5);
            nav.addView(n, lp);
            if (page.equals(p[0])) NavigationAnimator.selected(n, motion.enabled());
            n.setOnLongClickListener(new View.OnLongClickListener(){
                
                public boolean onLongClick(View v) {
                    toast(p[0], false);
                    return true;
                }
            });
            n.setOnClickListener(new View.OnClickListener(){
                
                public void onClick(View v) {
                    prefs.set("scroll." + page, scroll.getScrollY());
                    page = p[0];
                    prefs.set("page", page);
                    haptics.tick(v);
                    sounds.play(false);
                    makeNav();
                    render();
                    scroll.post(new Runnable(){
                        
                        public void run() {
                            scroll.scrollTo(0, prefs.integer("scroll." + page, 0));
                        }
                    });
                }
            });
        }
    }
    
    public void show() {
        if (closed) return;
        visible = true;
        pinned.setVisibility(View.GONE);
        ambient.setVisibility(prefs.bool("ambientGlow", true) ? View.VISIBLE : View.GONE);
        launcher.setVisibility(View.GONE);
        panel.setVisibility(View.VISIBLE);
        panel.requestFocus();
        sizePanel();
        motion.panel(panel);
        handler.removeCallbacks(poll);
        refresh();
    }
    
    void hide() {
        if (!visible) return;
        visible = false;
        pinned.setVisibility(prefs.bool("pinStatus", false) ? View.VISIBLE : View.GONE);
        ambient.setVisibility(View.GONE);
        prefs.set("scroll." + page, scroll.getScrollY());
        hideKeyboard();
        motion.exit(panel, new Runnable(){
            
            public void run() {
                if (!visible) {
                    panel.setVisibility(View.GONE);
                    panel.clearFocus();
                    launcher.setVisibility(View.VISIBLE);
                }
            }
        });
    }
    
    void quick() {
        final String[] options = {"Open menu", "Stop all automation", launcher.compact() ? "Expand launcher" : "Collapse to edge handle"};
        final AlertDialog d = new AlertDialog.Builder(new ContextThemeWrapper(activity, android.R.style.Theme_DeviceDefault_Dialog_Alert)).setTitle("Dynamon Gamer").setItems(options, new DialogInterface.OnClickListener(){
            
            public void onClick(DialogInterface d, int which) {
                if (which == 0) show(); else if (which == 1) command("stopAll", new JSONObject(), null); else launcher.compact(!launcher.compact());
            }
        }).create();
        track(d);
        d.show();
    }
    
    private void hideKeyboard() {
        try {
            ((android.view.inputmethod.InputMethodManager)activity.getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(panel.getWindowToken(), 0);
        } catch (Exception ignored) {
        }
    }
    
    void refresh() {
        if (closed || paused || requesting) return;
        requesting = true;
        game.snapshot(new GameConnection.Callback(){
            
            public void result(JSONObject s) {
                requesting = false;
                if (closed) return;
                state = s;
                updateState();
                handler.removeCallbacks(poll);
                if (!paused) handler.postDelayed(poll, visible ? 1200 : 4000);
            }
        });
    }
    
    private void updateState() {
        if (pinned != null) pinned.state(state);
        boolean ready = state.optBoolean("ready");
        connection.setText(game.preview() ? "\u25cf  PREVIEW  \u00b7  Sample data; game unchanged" : ready ? "\u25cf  GAME CONNECTED" : "\u25cb  " + state.optString("error", "Waiting for game"));
        connection.setTextColor(ready ? RoyalVoidTheme.GREEN : RoyalVoidTheme.MUTED);
        JSONObject f = state.optJSONObject("flags");
        JSONObject l = state.optJSONObject("locks");
        for (String k : switches.keySet()) {
            ToggleView t = switches.get(k);
            boolean on = f != null && f.optBoolean(k);
            boolean lock = l != null && l.optBoolean(k);
            t.state(on, lock, motion.enabled());
            t.setAlpha(ready ? 1 : 0.45F);
        }
        if (statLabels.size() >= 3) {
            statLabels.get(0).setText(ready ? format(state.optLong("coins")) : "\u2014");
            statLabels.get(1).setText(ready ? format(state.optLong("dust")) : "\u2014");
            statLabels.get(2).setText(ready ? String.format(java.util.Locale.US, "%.1f\u00d7", state.optDouble("speed", 1)) : "\u2014");
        }
        JSONObject aw = state.optJSONObject("world");
        if (ring != null && aw != null) {
            ring.progress((float)aw.optDouble("pct", 0), motion.enabled() && visible);
            worldLabel.setText((aw.optBoolean("paused") ? "PAUSED" : aw.optBoolean("on") ? "RUNNING" : "IDLE") + "  \u00b7  " + aw.optString("map", "Open a world map").replace('_', ' '));
            worldStats.setText(aw.optInt("bosses") + " bosses  \u00b7  " + aw.optInt("quests") + " quests\n" + duration(aw.optLong("elapsed")) + " elapsed  \u00b7  " + aw.optInt("left") + " remaining");
        }
        JSONObject current = state.optJSONObject(automationWorld ? "world" : "grind");
        if (pauseButton != null) {
            boolean on = current != null && current.optBoolean("on");
            pauseButton.setEnabled(on);
            pauseButton.setAlpha(on ? 1 : 0.45F);
            pauseButton.setText(current != null && current.optBoolean("paused") ? "Resume" : "Pause");
        }
        if (grindLabel != null) {
            JSONObject g = state.optJSONObject("grind");
            grindLabel.setText(g != null && g.optBoolean("on") ? (g.optBoolean("paused") ? "PAUSED" : "RUNNING") : "IDLE");
        }
    }
    
    private String format(long v) {
        return java.text.NumberFormat.getIntegerInstance().format(v);
    }
    
    private String duration(long ms) {
        long s = ms / 1000;
        return String.format(java.util.Locale.US, "%02d:%02d", s / 60, s % 60);
    }
    
    void command(final String name, JSONObject a, final GameConnection.Callback after) {
        if (closed) return;
        final String id = name + ":" + a.optString("key", a.optString("id", ""));
        if (inFlight.contains(id)) {
            toast("Waiting for the game\u2026", false);
            return;
        }
        inFlight.add(id);
        game.command(name, a, new GameConnection.Callback(){
            
            public void result(JSONObject r) {
                inFlight.remove(id);
                if (closed) return;
                boolean ok = r.optBoolean("ok");
                if (!ok) toast(r.optString("error", "Action failed"), true); else {
                    if (!name.equals("items") && !name.equals("scan")) {
                        haptics.success(panel);
                        sounds.play(true);
                        toast(r.optString("message", game.preview() ? "Preview updated" : "Applied"), false);
                    }
                }
                if (after != null) after.result(r);
                if (!name.equals("items") && !name.equals("scan")) refresh();
            }
        });
    }
    
    JSONObject args(Object... values) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i < values.length; i += 2) o.put((String)values[i], values[i + 1]);
        } catch (Exception ignored) {
        }
        return o;
    }
    
    void toast(String message, boolean error) {
        if (closed) return;
        if (error) {
            haptics.warning(panel);
            sounds.warn();
        }
        if (notice != null) root.removeView(notice);
        final TextView t = text(message, 13, RoyalVoidTheme.TEXT, false);
        notice = t;
        t.setPadding(dp(16), dp(12), dp(16), dp(12));
        t.setGravity(Gravity.CENTER);
        t.setBackground(RoyalVoidTheme.shape(error ? -12115144 : RoyalVoidTheme.DEEP, error ? RoyalVoidTheme.RED : RoyalVoidTheme.PURPLE, dp(16)));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Math.min(Math.max(dp(180), root.getWidth() - dp(40)), dp(420)), -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        lp.bottomMargin = dp(24);
        root.addView(t, lp);
        motion.enter(t, 0);
        t.announceForAccessibility(message);
        handler.postDelayed(new Runnable(){
            
            public void run() {
                root.removeView(t);
                if (notice == t) notice = null;
            }
        }, 3000);
    }
    
    TextView text(String s, int size, int color, boolean bold) {
        return RoyalVoidTheme.text(activity, s, size, color, bold);
    }
    
    LinearLayout row() {
        LinearLayout l = new LinearLayout(activity);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }
    
    LinearLayout column() {
        LinearLayout l = new LinearLayout(activity);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
    
    LinearLayout card() {
        LinearLayout l = column();
        l.setPadding(dp(14), dp(14), dp(14), dp(14));
        l.setBackground(new GlassPanelDrawable(dp(18), false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(12);
        body.addView(l, lp);
        return l;
    }
    
    void section(String title, String desc) {
        TextView t = text(title, 22, RoyalVoidTheme.TEXT, true);
        t.setPadding(0, dp(6), 0, dp(8));
        body.addView(t);
        if (desc != null) {
            TextView d = text(desc, 12, RoyalVoidTheme.MUTED, false);
            d.setLineSpacing(dp(3), 1);
            d.setPadding(0, 0, 0, dp(14));
            body.addView(d);
        }
    }
    
    EditText input(String hint, boolean numeric) {
        EditText e = new EditText(activity);
        e.setTextColor(RoyalVoidTheme.TEXT);
        e.setHintTextColor(RoyalVoidTheme.MUTED);
        e.setTypeface(FontManager.get(activity, "regular"));
        e.setTextSize(14);
        e.setSingleLine(true);
        e.setPadding(dp(12), 0, dp(12), 0);
        e.setHint(hint);
        e.setContentDescription(hint);
        e.setBackground(RoyalVoidTheme.shape(-15331549, RoyalVoidTheme.LINE, dp(12)));
        if (numeric) e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        return e;
    }
    
    View iconButton(String icon, String label, final Runnable action) {
        FrameLayout f = new FrameLayout(activity);
        f.setContentDescription(label);
        f.setFocusable(true);
        f.setClickable(true);
        f.setBackground(RoyalVoidTheme.shape(539959365, RoyalVoidTheme.LINE, dp(14)));
        f.addView(new IconView(activity, icon, RoyalVoidTheme.LAVENDER), new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER));
        f.setLayoutParams(new LinearLayout.LayoutParams(dp(48), dp(48)));
        f.setOnClickListener(new View.OnClickListener(){
            
            public void onClick(View v) {
                haptics.tick(v);
                action.run();
            }
        });
        return f;
    }
    
    TextView button(String label, boolean primary, final Runnable action) {
        final TextView b = text(label, 13, primary ? RoyalVoidTheme.TEXT : RoyalVoidTheme.LAVENDER, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(10), dp(12), dp(10), dp(12));
        b.setMinHeight(dp(48));
        b.setFocusable(true);
        b.setBackground(RoyalVoidTheme.shape(primary ? RoyalVoidTheme.DEEP : 539761475, primary ? RoyalVoidTheme.PURPLE : RoyalVoidTheme.LINE, dp(14)));
        b.setOnTouchListener(new View.OnTouchListener(){
            
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) motion.press(v, true);
                if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) motion.press(v, false);
                return false;
            }
        });
        b.setOnClickListener(new View.OnClickListener(){
            
            public void onClick(View v) {
                haptics.tick(v);
                sounds.play(false);
                action.run();
            }
        });
        return b;
    }
    
    void addButton(LinearLayout parent, String label, boolean primary, Runnable action) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(8);
        parent.addView(button(label, primary, action), lp);
    }
    
    private void feature(final FeatureRegistry.Feature f) {
        LinearLayout c = card();
        LinearLayout r = row();
        r.setGravity(Gravity.CENTER_VERTICAL);
        c.addView(r);
        r.addView(new IconView(activity, f.icon, RoyalVoidTheme.LAVENDER), new LinearLayout.LayoutParams(dp(23), dp(23)));
        LinearLayout labels = column();
        labels.setPadding(dp(10), 0, dp(4), 0);
        TextView title = text(f.title, 14, RoyalVoidTheme.TEXT, true);
        labels.addView(title);
        TextView detail = text(f.description, 11, RoyalVoidTheme.MUTED, false);
        detail.setPadding(0, dp(4), 0, 0);
        labels.addView(detail);
        r.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
        final ToggleView toggle = new ToggleView(activity);
        toggle.setContentDescription(f.title);
        r.addView(toggle, new LinearLayout.LayoutParams(dp(48), dp(48)));
        switches.put(f.key, toggle);
        toggle.setOnClickListener(new View.OnClickListener(){
            
            public void onClick(View v) {
                haptics.tick(v);
                command("flag", args("key", f.key, "value", !toggle.checked()), null);
            }
        });
        TextView favorite = text(prefs.favorite(f.key) ? "\u2605  FAVORITE" : "\u2606  HOLD TO FAVORITE", 9, RoyalVoidTheme.LAVENDER, true);
        favorite.setPadding(dp(33), dp(8), 0, 0);
        c.addView(favorite);
        c.setOnLongClickListener(new View.OnLongClickListener(){
            
            public boolean onLongClick(View v) {
                boolean on = prefs.flipFavorite(f.key);
                haptics.warning(v);
                toast(on ? "Added to favorites" : "Removed from favorites", false);
                render();
                return true;
            }
        });
    }
    
    void render() {
        if (body == null) return;
        body.removeAllViews();
        switches.clear();
        statLabels.clear();
        ring = null;
        worldLabel = null;
        worldStats = null;
        pauseButton = null;
        grindLabel = null;
        if (query.length() > 0) {
            section("Search", "Results across all feature groups");
            int n = 0;
            for (FeatureRegistry.Feature f : FeatureRegistry.ALL) if ((f.title + " " + f.description + " " + f.category).toLowerCase(java.util.Locale.US).contains(query)) {
                feature(f);
                n++;
            }
            if (n == 0) section("No matches", "Try a different feature name.");
        } else if (page.equals("Home")) home(); else if (page.equals("Battle")) {
            section("Battle", "Live controls for your active team.");
            features("Battle");
        } else if (page.equals("Arena")) {
            section("Arena", "Existing game hooks; availability depends on your game version.");
            automation(false);
            features("Arena");
        } else if (page.equals("Items")) itemsPage(); else if (page.equals("Unlock")) unlockPage(); else if (page.equals("Team")) teamPage(); else if (page.equals("Skins")) skinsPage(); else if (page.equals("Advanced")) {
            section("Advanced", "These controls require the matching patches in the game payload.");
            features("Advanced");
        } else if (page.equals("Settings")) settingsPage(); else if (page.equals("Community")) community();
        updateState();
        if (scrollMotion != null) scrollMotion.reset();
    }
    
    private void features(String category) {
        for (FeatureRegistry.Feature f : FeatureRegistry.ALL) if (f.category.equals(category)) feature(f);
    }
    
    private void home() {
        section("Your command centre", game.preview() ? "Preview mode. Explore the design with sample data." : "Your team, favorite controls and world progress.");
        LinearLayout c = card();
        String[] labels = {"COINS", "DUST", "GAME SPEED"};
        for (String s : labels) {
            LinearLayout r = row();
            r.setPadding(0, dp(5), 0, dp(5));
            r.addView(text(s, 10, RoyalVoidTheme.MUTED, true), new LinearLayout.LayoutParams(0, -2, 1));
            TextView v = text("\u2014", 18, RoyalVoidTheme.TEXT, true);
            statLabels.add(v);
            r.addView(v);
            c.addView(r);
        }
        addButton(c, "Edit coins & dust", true, new Runnable(){
            
            public void run() {
                currencyDialog();
            }
        });
        speedCard();
        automation(true);
        section("Favorites", "Long press a feature card to pin it here.");
        int n = 0;
        for (FeatureRegistry.Feature f : FeatureRegistry.ALL) if (prefs.favorite(f.key)) {
            feature(f);
            n++;
        }
        if (n == 0) {
            TextView t = text("Your favorites will appear here.", 12, RoyalVoidTheme.MUTED, false);
            body.addView(t);
        }
    }
    
    private void speedCard() {
        LinearLayout c = card();
        c.addView(text("GAME SPEED", 11, RoyalVoidTheme.LAVENDER, true));
        final TextView value = text(String.format(java.util.Locale.US, "%.1f\u00d7", state.optDouble("speed", 1)), 24, RoyalVoidTheme.TEXT, true);
        c.addView(value);
        SeekBar slider = new SeekBar(activity);
        slider.setMax(79);
        slider.setProgress((int)Math.round(state.optDouble("speed", 1) * 10) - 1);
        slider.setContentDescription("Game speed from 0.1 to 8 times");
        try {
            slider.getProgressDrawable().setColorFilter(RoyalVoidTheme.PURPLE, android.graphics.PorterDuff.Mode.SRC_IN);
            slider.getThumb().setColorFilter(RoyalVoidTheme.LAVENDER, android.graphics.PorterDuff.Mode.SRC_IN);
        } catch (Exception ignored) {
        }
        c.addView(slider, new LinearLayout.LayoutParams(-1, dp(48)));
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            
            public void onProgressChanged(SeekBar b, int v, boolean from) {
                value.setText(String.format(java.util.Locale.US, "%.1f\u00d7", (v + 1) / 10.0));
            }
            
            public void onStartTrackingTouch(SeekBar b) {
            }
            
            public void onStopTrackingTouch(SeekBar b) {
                command("speed", args("value", (b.getProgress() + 1) / 10.0), null);
            }
        });
    }
    
    private void automation(final boolean world) {
        automationWorld = world;
        LinearLayout c = card();
        c.addView(text(world ? "AUTO WORLD" : "ARENA AUTOMATION", 11, RoyalVoidTheme.LAVENDER, true));
        if (world) {
            LinearLayout r = row();
            r.setGravity(Gravity.CENTER_VERTICAL);
            ring = new ProgressRingView(activity);
            r.addView(ring, new LinearLayout.LayoutParams(dp(76), dp(76)));
            LinearLayout detail = column();
            detail.setPadding(dp(12), dp(8), 0, dp(8));
            worldLabel = text("IDLE", 12, RoyalVoidTheme.TEXT, true);
            worldStats = text("", 11, RoyalVoidTheme.MUTED, false);
            detail.addView(worldLabel);
            detail.addView(worldStats);
            r.addView(detail, new LinearLayout.LayoutParams(0, -2, 1));
            c.addView(r);
        } else {
            grindLabel = text("IDLE", 14, RoyalVoidTheme.TEXT, true);
            c.addView(grindLabel);
            c.addView(text("Automatically play bot matches while the game is in the foreground.", 12, RoyalVoidTheme.MUTED, false));
        }
        addButton(c, "Start", true, new Runnable(){
            
            public void run() {
                command("flag", args("key", world ? "autoWorld" : "autoGrind", "value", true), null);
            }
        });
        pauseButton = button("Pause", false, new Runnable(){
            
            public void run() {
                JSONObject current = state.optJSONObject(world ? "world" : "grind");
                command("pause", args("kind", world ? "world" : "grind", "value", !(current != null && current.optBoolean("paused"))), null);
            }
        });
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2);
        pp.topMargin = dp(8);
        c.addView(pauseButton, pp);
        addButton(c, "Stop & restore controls", false, new Runnable(){
            
            public void run() {
                command("flag", args("key", world ? "autoWorld" : "autoGrind", "value", false), null);
            }
        });
    }
    
    private void currencyDialog() {
        final LinearLayout c = column();
        c.setPadding(dp(20), dp(12), dp(20), 0);
        final EditText coins = input("Coins", true);
        final EditText dust = input("Dust", true);
        coins.setText(String.valueOf(state.optLong("coins")));
        dust.setText(String.valueOf(state.optLong("dust")));
        c.addView(text("Coins", 12, RoyalVoidTheme.MUTED, false));
        c.addView(coins, new LinearLayout.LayoutParams(-1, dp(48)));
        c.addView(text("Dust", 12, RoyalVoidTheme.MUTED, false));
        c.addView(dust, new LinearLayout.LayoutParams(-1, dp(48)));
        dialog("Currency", c, "Apply", new Runnable(){
            
            public void run() {
                try {
                    long a = Long.parseLong(coins.getText().toString());
                    long b = Long.parseLong(dust.getText().toString());
                    command("coins", args("value", a), null);
                    command("dust", args("value", b), null);
                } catch (Exception e) {
                    toast("Enter valid whole numbers", true);
                }
            }
        });
    }
    
    private void itemsPage() {
        section("Inventory", "Search items and adjust quantities.");
        final EditText filter = input("Filter item names", false);
        body.addView(filter, new LinearLayout.LayoutParams(-1, dp(48)));
        final LinearLayout results = column();
        body.addView(results);
        final JSONArray[] loaded = {new JSONArray()};
        final Runnable draw = new Runnable(){
            
            public void run() {
                results.removeAllViews();
                String q = filter.getText().toString().toLowerCase(java.util.Locale.US);
                int shown = 0;
                for (int i = 0; i < loaded[0].length(); i++) {
                    final JSONObject item = loaded[0].optJSONObject(i);
                    if (item == null || !item.optString("title").toLowerCase(java.util.Locale.US).contains(q)) continue;
                    if (++shown > 60) {
                        results.addView(text("Refine your search to see more items.", 12, RoyalVoidTheme.MUTED, false));
                        break;
                    }
                    LinearLayout c = column();
                    c.setPadding(dp(10), dp(10), dp(10), dp(10));
                    c.setBackground(new GlassPanelDrawable(dp(14), false));
                    LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
                    cp.topMargin = dp(8);
                    results.addView(c, cp);
                    c.addView(text(item.optString("title"), 13, RoyalVoidTheme.TEXT, true));
                    addButton(c, "Quantity: " + item.optInt("amount") + "  \u00b7  Edit", false, new Runnable(){
                        
                        public void run() {
                            numberDialog(item.optString("title"), item.optInt("amount"), new NumberAction(){
                                
                                public void apply(long n) {
                                    command("item", args("id", item.optString("id"), "value", n), null);
                                }
                            });
                        }
                    });
                }
            }
        };
        command("items", new JSONObject(), new GameConnection.Callback(){
            
            public void result(JSONObject r) {
                if (!r.optBoolean("ok")) return;
                loaded[0] = r.optJSONArray("items");
                if (loaded[0] == null) loaded[0] = new JSONArray();
                draw.run();
            }
        });
        filter.addTextChangedListener(new TextWatcher(){
            
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {
            }
            
            public void onTextChanged(CharSequence s, int st, int before, int c) {
                draw.run();
            }
            
            public void afterTextChanged(Editable e) {
            }
        });
        addButton(body, "Set all consumables", false, new Runnable(){
            
            public void run() {
                numberDialog("Set all consumables", 99, new NumberAction(){
                    
                    public void apply(final long n) {
                        confirm("Set every consumable to " + n + "?", new Runnable(){
                            
                            public void run() {
                                command("allItems", args("value", n), null);
                            }
                        });
                    }
                });
            }
        });
    }
    
    private void unlockPage() {
        section("Collection", "Unlock actions update local game records. Some screens refresh after reopening.");
        String[][] kinds = {{"Mons", "DynaDex capture records"}, {"Skins", "Available skin inventory"}, {"Emotes", "Available emotes"}, {"Avatars", "Available suit avatars"}};
        for (final String[] kind : kinds) {
            LinearLayout c = card();
            c.addView(text(kind[1], 15, RoyalVoidTheme.TEXT, true));
            addButton(c, "Unlock", true, new Runnable(){
                
                public void run() {
                    confirm("Update " + kind[1].toLowerCase(java.util.Locale.US) + "?", new Runnable(){
                        
                        public void run() {
                            command("unlock", args("kind", kind[0]), null);
                        }
                    });
                }
            });
        }
    }
    
    private void teamPage() {
        section("Team studio", "Scan again after changing battles or switching monsters.");
        LinearLayout size = card();
        size.addView(text("PARTY SIZE", 11, RoyalVoidTheme.LAVENDER, true));
        for (int i = 3; i <= 5; i++) {
            final int n = i;
            addButton(size, n + " Dynamons", state.optInt("party", 3) == i, new Runnable(){
                
                public void run() {
                    command("party", args("value", n), null);
                }
            });
        }
        final LinearLayout results = column();
        addButton(body, "Scan team & enemy", true, new Runnable(){
            
            public void run() {
                command("scan", new JSONObject(), new GameConnection.Callback(){
                    
                    public void result(JSONObject r) {
                        if (!r.optBoolean("ok")) return;
                        results.removeAllViews();
                        JSONArray mons = r.optJSONArray("mons");
                        final String token = r.optString("token");
                        if (mons == null) return;
                        for (int i = 0; i < mons.length(); i++) {
                            final JSONObject m = mons.optJSONObject(i);
                            if (m == null) continue;
                            LinearLayout c = column();
                            c.setPadding(dp(12), dp(14), dp(12), dp(14));
                            c.setBackground(new GlassPanelDrawable(dp(16), false));
                            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
                            lp.topMargin = dp(10);
                            results.addView(c, lp);
                            c.addView(text(m.optString("side").toUpperCase(java.util.Locale.US), 10, RoyalVoidTheme.LAVENDER, true));
                            c.addView(text(m.optString("name"), 18, RoyalVoidTheme.TEXT, true));
                            c.addView(text("HP " + m.optInt("hp") + " / " + m.optInt("max"), 12, RoyalVoidTheme.MUTED, false));
                            for (final String stat : new String[]{"hp", "atk", "def", "aim"}) {
                                addButton(c, stat.toUpperCase(java.util.Locale.US) + "  " + m.optInt(stat), false, new Runnable(){
                                    
                                    public void run() {
                                        numberDialog(stat.toUpperCase(java.util.Locale.US), m.optInt(stat), new NumberAction(){
                                            
                                            public void apply(long n) {
                                                command("stat", args("token", token, "index", m.optInt("index"), "stat", stat, "value", n), null);
                                            }
                                        });
                                    }
                                });
                            }
                        }
                    }
                });
            }
        });
        body.addView(results);
    }
    
    private void skinsPage() {
        section("Skin atelier", "Load a pack from your existing Supabase storage. Saved changes apply after restarting the game.");
        final EditText pack = input("Pack folder name", false);
        pack.setText(prefs.string("skinPack", "mypack"));
        body.addView(pack, new LinearLayout.LayoutParams(-1, dp(48)));
        final LinearLayout results = column();
        addButton(body, "Load manifest", true, new Runnable(){
            
            public void run() {
                final String id = pack.getText().toString().trim();
                toast("Loading skin pack\u2026", false);
                skins.load(id, new SkinPackManager.Callback(){
                    
                    public void result(final JSONObject manifest, String error) {
                        if (error != null) {
                            toast(error, true);
                            return;
                        }
                        prefs.set("skinPack", id);
                        results.removeAllViews();
                        results.addView(text(manifest.optString("title", id), 17, RoyalVoidTheme.TEXT, true));
                        final ArrayList<String> all = new ArrayList<String>();
                        Object mons = manifest.opt("mons");
                        if (mons instanceof JSONObject) {
                            Iterator<String> it = ((JSONObject)mons).keys();
                            while (it.hasNext()) all.add(it.next());
                        } else if (mons instanceof JSONArray) {
                            JSONArray ar = (JSONArray)mons;
                            for (int i = 0; i < ar.length(); i++) all.add(ar.optString(i));
                        }
                        JSONObject names = manifest.optJSONObject("names");
                        if (names != null) {
                            Iterator<String> it = names.keys();
                            while (it.hasNext()) {
                                String k = it.next();
                                if (!all.contains(k)) all.add(k);
                            }
                        }
                        Collections.sort(all);
                        final HashSet<String> selected = new HashSet<String>();
                        int shown = 0;
                        for (final String mon : all) {
                            if (++shown > 60) {
                                results.addView(text("Showing the first 60. Apply to all includes the full pack.", 11, RoyalVoidTheme.MUTED, false));
                                break;
                            }
                            final CheckBox cb = new CheckBox(activity);
                            cb.setText(names == null ? mon : names.optString(mon, mon));
                            cb.setTextColor(RoyalVoidTheme.TEXT);
                            cb.setTypeface(FontManager.get(activity, "regular"));
                            cb.setMinHeight(dp(48));
                            LinearLayout skinRow = row();
                            skinRow.setGravity(Gravity.CENTER_VERTICAL);
                            ArtworkView icon = new ArtworkView(activity);
                            skinRow.addView(icon, new LinearLayout.LayoutParams(dp(40), dp(40)));
                            skins.loadIcon(id, mon, icon);
                            skinRow.addView(cb, new LinearLayout.LayoutParams(0, -2, 1));
                            results.addView(skinRow);
                            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
                                
                                public void onCheckedChanged(CompoundButton b, boolean on) {
                                    if (on) selected.add(mon); else selected.remove(mon);
                                }
                            });
                        }
                        addButton(results, "Save selected", true, new Runnable(){
                            
                            public void run() {
                                command("skinConfig", args("pack", id, "manifest", manifest, "enabled", new JSONArray(selected)), null);
                            }
                        });
                        addButton(results, "Apply to all", false, new Runnable(){
                            
                            public void run() {
                                command("skinConfig", args("pack", id, "manifest", manifest, "enabled", new JSONArray(all)), null);
                            }
                        });
                    }
                });
            }
        });
        addButton(body, "Restore original artwork", false, new Runnable(){
            
            public void run() {
                command("resetSkins", new JSONObject(), null);
            }
        });
        body.addView(results);
    }
    
    private void settingsPage() {
        section("Make it yours", "Your preferences stay on this device. Background automation depends on the host game.");
        setting("Haptic feedback", "haptics", true);
        setting("Interface sounds", "sounds", false);
        setting("Subtle 3D depth", "depth", true);
        setting("Ambient glow", "ambientGlow", true);
        setting("Pinned automation status", "pinStatus", false);
        setting("Reduced motion", "reducedMotion", false);
        LinearLayout c = card();
        c.addView(text("PANEL SIZE", 11, RoyalVoidTheme.LAVENDER, true));
        SeekBar size = new SeekBar(activity);
        size.setMax(35);
        size.setProgress((int)(prefs.number("panelHeight", 0.9F) * 100) - 60);
        c.addView(size, new LinearLayout.LayoutParams(-1, dp(48)));
        size.setContentDescription("Menu height");
        size.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            
            public void onProgressChanged(SeekBar b, int n, boolean user) {
                if (user) {
                    prefs.set("panelHeight", (n + 60) / 100.0F);
                    sizePanel();
                }
            }
            
            public void onStartTrackingTouch(SeekBar b) {
            }
            
            public void onStopTrackingTouch(SeekBar b) {
            }
        });
        addButton(c, "Toggle compact edge launcher", false, new Runnable(){
            
            public void run() {
                launcher.compact(!launcher.compact());
                toast("Launcher preference saved", false);
            }
        });
        LinearLayout profiles = card();
        profiles.addView(text("CONTROL PROFILE", 11, RoyalVoidTheme.LAVENDER, true));
        addButton(profiles, "Save a named profile", true, new Runnable(){
            
            public void run() {
                final JSONObject f = state.optJSONObject("flags");
                if (f == null) {
                    toast("Connect to the game first", true);
                    return;
                }
                final EditText name = input("Profile name", false);
                name.setText("My controls");
                LinearLayout box = column();
                box.setPadding(dp(20), dp(12), dp(20), 0);
                box.addView(name, new LinearLayout.LayoutParams(-1, dp(48)));
                dialog("Save profile", box, "Save", new Runnable(){
                    
                    public void run() {
                        try {
                            new ProfileStore(prefs).save(name.getText().toString(), f);
                            toast("Profile saved; automation excluded", false);
                        } catch (Exception e) {
                            toast(e.getMessage(), true);
                        }
                    }
                });
            }
        });
        addButton(profiles, "Restore a profile", false, new Runnable(){
            
            public void run() {
                final ProfileStore store = new ProfileStore(prefs);
                ArrayList<String> ns = store.names();
                if (ns.isEmpty()) {
                    toast("Save a profile first", false);
                    return;
                }
                final String[] names = ns.toArray(new String[ns.size()]);
                AlertDialog d = new AlertDialog.Builder(new ContextThemeWrapper(activity, android.R.style.Theme_DeviceDefault_Dialog_Alert)).setTitle("Restore controls").setItems(names, new DialogInterface.OnClickListener(){
                    
                    public void onClick(DialogInterface dialog, int which) {
                        final String name = names[which];
                        final JSONObject values = store.read(name);
                        confirm("Apply " + name + " (" + values.length() + " saved switches)?", new Runnable(){
                            
                            public void run() {
                                command("profile", args("values", values), null);
                            }
                        });
                    }
                }).create();
                track(d);
                d.show();
            }
        });
        addButton(body, "Stop all automation", false, new Runnable(){
            
            public void run() {
                command("stopAll", new JSONObject(), null);
            }
        });
    }
    
    private void setting(String label, final String key, boolean fallback) {
        LinearLayout c = card();
        LinearLayout r = row();
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(text(label, 13, RoyalVoidTheme.TEXT, true), new LinearLayout.LayoutParams(0, -2, 1));
        final ToggleView t = new ToggleView(activity);
        t.setContentDescription(label);
        t.state(prefs.bool(key, fallback), false, false);
        r.addView(t, new LinearLayout.LayoutParams(dp(48), dp(48)));
        c.addView(r);
        t.setOnClickListener(new View.OnClickListener(){
            
            public void onClick(View v) {
                boolean n = !t.checked();
                prefs.set(key, n);
                t.state(n, false, motion.enabled());
                haptics.tick(t);
                if (key.equals("sounds")) sounds.prepare();
                if (key.equals("ambientGlow")) ambient.setVisibility(n && visible ? View.VISIBLE : View.GONE);
            }
        });
    }
    
    private void community() {
        section("Dynamon Gamer", "Royal Void edition. Built for your Dynamons World experience.");
        LinearLayout c = card();
        ArtworkView logo = new ArtworkView(activity);
        logo.asset("royal_void/images/brand_logo.jpg");
        c.addView(logo, new LinearLayout.LayoutParams(-1, dp(112)));
        c.addView(text("Stay connected", 19, RoyalVoidTheme.TEXT, true));
        for (final String[] link : BrandConfig.LINKS) {
            LinearLayout r = row();
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.addView(new IconView(activity, link[2], RoyalVoidTheme.LAVENDER), new LinearLayout.LayoutParams(dp(24), dp(24)));
            TextView b = button(link[0], false, new Runnable(){
                
                public void run() {
                    try {
                        activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(link[1])));
                    } catch (ActivityNotFoundException e) {
                        toast("No app can open this link", true);
                    }
                }
            });
            r.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(8);
            c.addView(r, lp);
        }
        body.addView(text("Version " + BrandConfig.VERSION + " \u00b7 Open Sans typography", 11, RoyalVoidTheme.MUTED, false));
    }
    
    interface NumberAction {
        
        void apply(long n);
    }
    
    private void numberDialog(String title, long value, final NumberAction action) {
        final EditText e = input(title, true);
        e.setText(String.valueOf(value));
        LinearLayout box = column();
        box.setPadding(dp(20), dp(12), dp(20), 0);
        box.addView(e, new LinearLayout.LayoutParams(-1, dp(48)));
        dialog(title, box, "Apply", new Runnable(){
            
            public void run() {
                try {
                    action.apply(Long.parseLong(e.getText().toString()));
                } catch (Exception x) {
                    toast("Enter a valid whole number", true);
                }
            }
        });
    }
    
    private void confirm(String message, Runnable action) {
        LinearLayout box = column();
        box.setPadding(dp(20), dp(12), dp(20), 0);
        box.addView(text(message, 14, RoyalVoidTheme.TEXT, false));
        dialog("Confirm change", box, "Continue", action);
    }
    
    private void dialog(String title, View content, String positive, final Runnable action) {
        final AlertDialog d = new AlertDialog.Builder(new ContextThemeWrapper(activity, android.R.style.Theme_DeviceDefault_Dialog_Alert)).setTitle(title).setView(content).setNegativeButton("Cancel", null).setPositiveButton(positive, new DialogInterface.OnClickListener(){
            
            public void onClick(DialogInterface dialog, int which) {
                action.run();
            }
        }).create();
        track(d);
        d.show();
        if (d.getWindow() != null) d.getWindow().setBackgroundDrawable(new GlassPanelDrawable(dp(22), true));
        d.getButton(-1).setTextColor(RoyalVoidTheme.LAVENDER);
        d.getButton(-2).setTextColor(RoyalVoidTheme.MUTED);
    }
    
    private void track(final Dialog d) {
        dialogs.add(d);
        d.setOnDismissListener(new DialogInterface.OnDismissListener(){
            
            public void onDismiss(DialogInterface x) {
                dialogs.remove(d);
            }
        });
    }
    
    public void pause() {
        paused = true;
        handler.removeCallbacks(poll);
        if (panel != null) {
            panel.animate().setListener(null);
            panel.animate().cancel();
            if (!visible) {
                panel.setVisibility(View.GONE);
                launcher.setVisibility(View.VISIBLE);
            }
        }
    }
    
    public void resume() {
        paused = false;
        if (visible) {
            panel.setAlpha(prefs.number("opacity", 1));
            panel.setScaleX(1);
            panel.setScaleY(1);
            panel.setRotationX(0);
        }
        handler.removeCallbacks(poll);
        refresh();
    }
    
    public void close() {
        closed = true;
        handler.removeCallbacksAndMessages(null);
        game.close();
        if (scrollMotion != null) scrollMotion.close();
        skins.close();
        sounds.close();
        for (Dialog d : new ArrayList<Dialog>(dialogs)) d.dismiss();
        dialogs.clear();
        root.removeOnLayoutChangeListener(layoutListener);
        if (root.getParent() instanceof ViewGroup) ((ViewGroup)root.getParent()).removeView(root);
    }
}
