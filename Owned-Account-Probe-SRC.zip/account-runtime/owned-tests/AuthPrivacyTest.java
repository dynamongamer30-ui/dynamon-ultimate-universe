import org.microg.gms.common.AuthErrorPolicy;
import org.microg.gms.common.AuthStageObserver;
import org.microg.gms.auth.login.RegistrationPolicy;
import java.io.IOException;
public final class AuthPrivacyTest {
    static void require(boolean value) { if (!value) throw new AssertionError(); }
    public static void main(String[] args) throws Exception {
        String secret = "CANARY_password_cookie_oauth_refresh_token";
        require(AuthErrorPolicy.resolutionMessage("Error=" + secret).equals("Error=UNKNOWN"));
        require(AuthErrorPolicy.resolutionMessage("Error=BadAuthentication\nAuth=" + secret).equals("Error=BadAuthentication"));
        require(AuthErrorPolicy.resolutionMessage("Error=DeviceManagementRequired").equals("Error=DeviceManagementRequired"));
        require(AuthErrorPolicy.field("  ") == null);
        require(AuthErrorPolicy.field("Auth=x=y")[1].equals("x=y"));
        try { AuthErrorPolicy.field(secret); throw new AssertionError(); } catch (IOException e) { require(!e.toString().contains(secret)); }
        require(AuthStageObserver.classify(new IOException(secret, new java.net.UnknownHostException(secret))) == AuthStageObserver.Failure.DNS);
        require(AuthStageObserver.classify(new javax.net.ssl.SSLHandshakeException(secret)) == AuthStageObserver.Failure.TLS);
        require(AuthStageObserver.classify(new java.net.SocketTimeoutException(secret)) == AuthStageObserver.Failure.TIMEOUT);
        require(AuthStageObserver.classify(new SecurityException(secret)) == AuthStageObserver.Failure.IDENTITY);
        require(AuthStageObserver.classify(new org.microg.gms.common.NotOkayException("Error=UNKNOWN")) == AuthStageObserver.Failure.SERVER_REJECTED);
        require(org.microg.gms.common.CallerHintPolicy.uidMatches(0, 10033, 10182));
        require(org.microg.gms.common.CallerHintPolicy.uidMatches(10033, 10033, 10182));
        require(org.microg.gms.common.CallerHintPolicy.uidMatches(10182, 10033, 10182));
        require(!org.microg.gms.common.CallerHintPolicy.uidMatches(10037, 10033, 10182));
        require(!org.microg.gms.common.CallerHintPolicy.uidMatches(10182, 1000, 10182));
        StringBuilder events = new StringBuilder();
        AuthStageObserver.setSink((s, f, h) -> events.append(s.name()).append(f.name()).append(h));
        AuthStageObserver.failed(AuthStageObserver.Stage.MASTER_FAILURE, new IOException(secret));
        AuthStageObserver.event(AuthStageObserver.Stage.NETWORK_HTTP, AuthStageObserver.Failure.NONE, -1);
        require(!events.toString().contains(secret));
        require(events.toString().endsWith("NETWORK_HTTPNONE0"));
        AuthStageObserver.setSink((s, f, h) -> { throw new IllegalStateException(secret); });
        AuthStageObserver.event(AuthStageObserver.Stage.MASTER_START);
        require(!RegistrationPolicy.required(true, false, 0));
        require(!RegistrationPolicy.required(false, true, 0));
        require(!RegistrationPolicy.required(true, true, 100));
        require(RegistrationPolicy.required(true, true, 0));
        require(RegistrationPolicy.required(true, true, -1));
        System.out.println("24 redaction, protocol parsing, typed failure and opt-in registration scenarios passed");
    }
}
