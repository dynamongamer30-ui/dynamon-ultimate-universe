import org.microg.gms.auth.login.LoginPagePolicy;
import org.microg.gms.common.AuthNetworkPolicy;
public final class LoginPagePolicyTest {
 public static void main(String[] args) {
  String[] good={"https://accounts.google.com/EmbeddedSetup", "https://accounts.google.com:443/signin?x=1", "HTTPS://ACCOUNTS.GOOGLE.COM/", "https://accounts.google.com/#identifier"};
  String[] bad={null,"", "about:blank", "javascript:alert(1)", "http://accounts.google.com/", "https://accounts.google.com.evil.example/", "https://evil.example/accounts.google.com", "https://accounts.google.com@evil.example/", "https://user@accounts.google.com/", "https://accounts.google.com:444/", "https://accounts.google.com:80/", "https://accounts.google.com./", "//accounts.google.com/", "https://accounts.google.com/ bad"};
  for(String value:good) if(!LoginPagePolicy.isGoogleAccountPage(value)) throw new AssertionError("Legitimate Google page rejected");
  for(String value:bad) if(LoginPagePolicy.isGoogleAccountPage(value)) throw new AssertionError("Non-Google secure page accepted");
  if(LoginPagePolicy.COOKIE_DEADLINE_MS!=10000 || LoginPagePolicy.PAGE_DEADLINE_MS!=45000) throw new AssertionError("Login deadline contract changed");
  if(AuthNetworkPolicy.CONNECT_TIMEOUT_MS<=0 || AuthNetworkPolicy.CONNECT_TIMEOUT_MS>20000 || AuthNetworkPolicy.READ_TIMEOUT_MS<=0 || AuthNetworkPolicy.READ_TIMEOUT_MS>30000) throw new AssertionError("Unbounded authentication request");
  System.out.println("20 Google page and timeout policy checks passed");
 }
}
